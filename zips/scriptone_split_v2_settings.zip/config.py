# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, yaml

_SETTINGS_CACHE = None

def load_settings(path: str = "settings.yaml") -> dict:
    global _SETTINGS_CACHE
    if _SETTINGS_CACHE is not None:
        return _SETTINGS_CACHE
    if not os.path.exists(path):
        raise FileNotFoundError(f"File di impostazioni non trovato: {path}")
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    _SETTINGS_CACHE = data
    return data

def get_setting(key_path: str, default=None):
    """
    get_setting('database.path', 'output.db')
    """
    cur = load_settings()
    for part in key_path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur
