# -*- coding: utf-8 -*-
from __future__ import annotations
import sqlite3

def quote_ident(name: str) -> str:
    if '"' in name:
        name = name.replace('"', '""')
    return f'"{name}"'

def table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    cols = []
    cur = conn.execute(f"PRAGMA table_info({quote_ident(table)})")
    for _, name, _, _, _, _ in cur.fetchall():
        cols.append(name)
    return cols

def ensure_index(conn: sqlite3.Connection, table: str, column: str, unique: bool=True):
    idx_name = f"{table}_{column}_{'uq' if unique else 'idx'}"
    try:
        conn.execute(
            f"CREATE {'UNIQUE' if unique else ''} INDEX IF NOT EXISTS {quote_ident(idx_name)} "
            f"ON {quote_ident(table)} ({quote_ident(column)})"
        )
    except sqlite3.Error:
        pass

def ensure_ext_col_migrated(conn: sqlite3.Connection, table: str) -> str:
    cols = set(table_columns(conn, table))
    if "ext_id" in cols:
        ensure_index(conn, table, "ext_id", unique=True)
        return "ext_id"
    if "memento_id" in cols:
        conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN ext_id TEXT")
        conn.execute(f"UPDATE {quote_ident(table)} SET ext_id = memento_id WHERE ext_id IS NULL")
        ensure_index(conn, table, "ext_id", unique=True)
        conn.commit()
        return "ext_id"
    conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN ext_id TEXT")
    ensure_index(conn, table, "ext_id", unique=True)
    conn.commit()
    return "ext_id"
