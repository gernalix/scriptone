# -*- coding: utf-8 -*-
from __future__ import annotations
import requests, json, sqlite3
from typing import List, Dict, Any

from config import get_setting
from db_utils import quote_ident, ensure_ext_col_migrated

def _headers():
    token = get_setting("memento.token", "")
    return {"Authorization": f"Bearer {token}"} if token else {}

def _api(path: str) -> str:
    base = get_setting("memento.api_url", "").rstrip("/")
    return f"{base}/{path.lstrip('/')}"

def list_libraries() -> List[Dict[str, Any]]:
    url = _api("libraries")
    r = requests.get(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    data = r.json()
    # Normalizza formato
    if isinstance(data, dict) and "items" in data:
        return data["items"]
    if isinstance(data, list):
        return data
    return []

def infer_field_mapping(library_id: str, form_id: str|None=None) -> Dict[str, str]:
    # Strategia semplice: prendi 1 record e mappa tipi grossolani
    entry = _get_one_entry(library_id, form_id)
    mapping = {}
    if not entry:
        return mapping
    for k, v in entry.items():
        t = "integer" if isinstance(v, int) else "number" if isinstance(v, float) else "bool" if isinstance(v, bool) else "datetime" if "time" in k.lower() or "date" in k.lower() else "text"
        mapping[k] = t
    return mapping

def show_one_raw_entry(library_id: str, form_id: str|None=None) -> str:
    entry = _get_one_entry(library_id, form_id)
    return json.dumps(entry, ensure_ascii=False, indent=2)

def _get_one_entry(library_id: str, form_id: str|None=None) -> Dict[str, Any]:
    q = f"libraries/{library_id}/entries"
    if form_id:
        q = f"libraries/{library_id}/forms/{form_id}/entries"
    url = _api(q) + "?limit=1"
    r = requests.get(url, headers=_headers(), timeout=30)
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict):
        items = data.get("items") or data.get("results") or []
        return items[0] if items else {}
    if isinstance(data, list):
        return data[0] if data else {}
    return {}

def import_library_auto(db_path: str, library_id: str) -> int:
    """
    Import 'grezzo ma utile':
    - scarica entries della libreria
    - inserisce/aggiorna nella tabella con lo stesso nome della libreria (semplificazione)
    - normalizza alcuni campi standard se presenti.
    """
    # scarica entries (paginazione minimal: per demo; in produzione iterare pages)
    url = _api(f"libraries/{library_id}/entries")
    r = requests.get(url, headers=_headers(), timeout=60)
    r.raise_for_status()
    data = r.json()
    entries = data.get("items") if isinstance(data, dict) else data

    table = library_id  # semplice regola: tabella = id libreria
    tempo_col = "tempo"

    conn = sqlite3.connect(db_path)
    try:
        # Auto-migrazione ext_id/memento_id
        ext_col = ensure_ext_col_migrated(conn, table)
        # Crea colonna tempo e raw se servono
        conn.execute(f"CREATE TABLE IF NOT EXISTS {quote_ident(table)} (id INTEGER PRIMARY KEY AUTOINCREMENT)")
        try:
            conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(tempo_col)} TEXT")
        except Exception:
            pass
        try:
            conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN raw TEXT")
        except Exception:
            pass
        n = 0
        for e in entries:
            ext_id = str(e.get("id") or e.get("uuid") or e.get("key") or "")
            if not ext_id:
                continue
            tempo_val = e.get("time") or e.get("date") or e.get("created") or None
            raw_json = json.dumps(e, ensure_ascii=False)
            row = conn.execute(
                f"SELECT {quote_ident(ext_col)} FROM {quote_ident(table)} WHERE {quote_ident(ext_col)}=?",
                (ext_id,)
            ).fetchone()
            if row:
                conn.execute(
                    f"UPDATE {quote_ident(table)} SET {quote_ident(tempo_col)}=?, raw=? WHERE {quote_ident(ext_col)}=?",
                    (tempo_val, raw_json, ext_id)
                )
            else:
                conn.execute(
                    f"INSERT INTO {quote_ident(table)} ({quote_ident(ext_col)}, {quote_ident(tempo_col)}, raw) VALUES (?,?,?)",
                    (ext_id, tempo_val, raw_json)
                )
            n += 1
        conn.commit()
        return n
    finally:
        conn.close()
