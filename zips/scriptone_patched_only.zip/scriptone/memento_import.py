import json
import sqlite3
from typing import Any, Dict, List, Optional, Tuple

from db_utils import quote_ident, table_columns, ensure_ext_col_migrated, ensure_table_basic

def _ensure_table_columns(conn: sqlite3.Connection, table: str) -> None:
    """Ensure standard columns commonly used by Memento imports exist."""
    desired = {
        'raw': 'TEXT',
        'createdTime': 'TEXT',
        'modifiedTime': 'TEXT',
        'createdTime_remote': 'TEXT',
        'modifiedTime_remote': 'TEXT',
    }
    cols = table_columns(conn, table)
    for col, coltype in desired.items():
        if col not in cols:
            conn.execute(f'ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(col)} {coltype}')
    conn.commit()

def _insert_rows(conn: sqlite3.Connection, table: str, rows: List[Dict[str, Any]]) -> int:
    """Insert payload rows into table."""
    if not rows:
        return 0

    cols_in_table = table_columns(conn, table)
    all_keys = set().union(*(row.keys() for row in rows))
    missing = [k for k in all_keys if k not in cols_in_table]
    for k in missing:
        conn.execute(f'ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(k)} TEXT')
    conn.commit()

    ordered_cols = sorted(all_keys)
    placeholders = ", ".join(["?"] * len(ordered_cols))
    collist = ", ".join(quote_ident(c) for c in ordered_cols)

    inserted = 0
    with conn:
        for row in rows:
            values = [row.get(c) for c in ordered_cols]
            conn.execute(f'INSERT OR IGNORE INTO {quote_ident(table)} ({collist}) VALUES ({placeholders})', values)
            inserted += 1
    return inserted

def _import_entries(conn: sqlite3.Connection, table: str, entries: List[Dict[str, Any]], id_mode: str, tempo_col: Optional[str]) -> Tuple[int, int]:
    """Import a batch of entries into table."""
    ensure_table_basic(conn, table, tempo_col or "tempo")
    ext_col = ensure_ext_col_migrated(conn, table)
    _ensure_table_columns(conn, table)

    if not entries:
        return (0, 0)

    rows: List[Dict[str, Any]] = []
    for e in entries:
        row: Dict[str, Any] = dict(e)
        if id_mode == "id":
            row[ext_col] = str(e.get("id") or e.get("_id") or "")
        elif id_mode == "uuid":
            row[ext_col] = str(e.get("uuid") or "")
        elif id_mode == "hash":
            import hashlib, json as _json
            row[ext_col] = hashlib.sha1(_json.dumps(e, sort_keys=True).encode("utf-8")).hexdigest()
        else:
            row[ext_col] = str(e.get("id") or "")
        row.setdefault("raw", json.dumps(e, ensure_ascii=False))
        rows.append(row)

    inserted = _insert_rows(conn, table, rows)
    return (inserted, len(entries))
