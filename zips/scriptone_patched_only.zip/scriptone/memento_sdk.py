import os
import yaml
import requests

_SETTINGS_PATHS = (
    "./settings.yaml",
    "settings.yaml",
    os.path.join(os.path.dirname(__file__), "settings.yaml"),
)

def _load_settings():
    for p in _SETTINGS_PATHS:
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
    return {}

def _api(path: str) -> str:
    s = _load_settings()
    base = s.get("memento", {}).get("api_url") or "https://api.mementodatabase.com"
    return base.rstrip("/") + path

def _headers():
    s = _load_settings()
    token = s.get("memento", {}).get("token") or ""
    h = {"Accept": "application/json"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h

def list_libraries():
    url = _api("/libraries")
    r = requests.get(url, headers=_headers(), timeout=20)
    if r.status_code == 404:
        raise RuntimeError(
            "Memento Cloud API ha risposto 404 su /libraries. "
            "Possibili cause: token non valido, Cloud API non abilitata per l'account, "
            "oppure endpoint differente. Verifica 'memento.api_url' e 'memento.token' in settings.yaml."
        )
    r.raise_for_status()
    return r.json()
