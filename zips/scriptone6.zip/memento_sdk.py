from __future__ import annotations
import requests
from typing import Any, Dict, List
from config import get as cfg_get

def _session() -> requests.Session:
    s = requests.Session()
    token = cfg_get('memento.token','')
    if token:
        s.headers["Authorization"] = f"Bearer {token}"
    return s

def _base_url() -> str:
    return str(cfg_get("memento.api_url", "https://api.mementodatabase.com")).rstrip("/")

def _raise_on_404(resp: requests.Response, path: str) -> None:
    if resp.status_code == 404:
        raise RuntimeError(
            "Memento API ha risposto 404 su {path}. Possibili cause: token non valido, API non abilitata/endpoint errato.\n"
            f"URL chiamato: {resp.request.method} {resp.url}\n"
            f"Status: {resp.status_code}\n"
            f"Body: {resp.text[:500]}"
        )

def list_libraries() -> List[Dict[str, Any]]:
    s = _session()
    base = _base_url()
    url = f"{base}/libraries"
    r = s.get(url, timeout=int(cfg_get("memento.timeout", 20)))
    if r.status_code == 401:
        raise RuntimeError("Token non valido (401). Controlla 'memento.token' in settings.ini/yaml.")
    if r.status_code == 404:
        _raise_on_404(r, "/libraries")
    r.raise_for_status()
    data = r.json()
    libs = data.get("libraries") if isinstance(data, dict) else data
    if not isinstance(libs, list):
        raise RuntimeError(f"Risposta inattesa da /libraries: {data!r}")
    return libs

def infer_field_mapping(library_id: str) -> Dict[str, Any]:
    s = _session()
    base = _base_url()
    url = f"{base}/libraries/{library_id}/fields"
    r = s.get(url, timeout=int(cfg_get("memento.timeout", 20)))
    if r.status_code == 404:
        _raise_on_404(r, f"/libraries/{library_id}/fields")
    r.raise_for_status()
    return r.json()

def get_one_raw_entry(library_id: str, form_name: str) -> Dict[str, Any]:
    s = _session()
    base = _base_url()
    url = f"{base}/libraries/{library_id}/forms/{form_name}/entries?limit=1"
    r = s.get(url, timeout=int(cfg_get("memento.timeout", 20)))
    if r.status_code == 404:
        _raise_on_404(r, f"/libraries/{library_id}/forms/{form_name}/entries")
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict) and "entries" in data and data["entries"]:
        return data["entries"][0]
    if isinstance(data, list) and data:
        return data[0]
    return {}
