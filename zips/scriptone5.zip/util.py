# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, os
from typing import Optional, Iterable

def pause_if_needed(should_pause: bool):
    try:
        if should_pause:
            input("\nPremi Invio per uscire...")
    except EOFError:
        pass

def ensure_console_utf8():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

def input_int(prompt: str) -> int:
    try:
        return int(input(prompt).strip())
    except Exception:
        return -1

def _candidate_paths(path: str) -> Iterable[str]:
    """
    Genera candidati per un path (es. 'memento_import.yaml'):
    - Se assoluto ed esiste, restituisce così com'è.
    - CWD
    - Cartella dell'entry point (__main__.__file__)
    - Parent dell'entry point
    - Cartella di questo modulo
    """
    if not path:
        return []
    p = os.path.abspath(path)
    if os.path.isabs(path) and os.path.exists(path):
        yield path
        return
    # CWD
    yield os.path.abspath(path)
    # Entry point
    try:
        import __main__
        if hasattr(__main__, "__file__"):
            main_dir = os.path.dirname(os.path.abspath(__main__.__file__))
            yield os.path.join(main_dir, path)
            yield os.path.join(os.path.dirname(main_dir), path)
    except Exception:
        pass
    # Modulo corrente
    here = os.path.dirname(os.path.abspath(__file__))
    yield os.path.join(here, path)

def resolve_path(path: str) -> str:
    for cand in _candidate_paths(path):
        if os.path.exists(cand):
            return cand
    tried = "\n - ".join(list(_candidate_paths(path)))
    raise FileNotFoundError(f"file non trovato: {path}\nPercorsi verificati:\n - {tried}")

def ensure_path(path: str, should_exist: bool, kind: str) -> str:
    """
    Come prima, ma ritorna il path risolto e supporta lookup robusto quando should_exist=True.
    """
    if should_exist:
        return resolve_path(path)
    # Se non deve esistere, normalizza comunque rispetto a CWD
    return os.path.abspath(path)

def color(name: str, text: str) -> str:
    colors = {"giallo":"\033[33m","verde":"\033[32m","rosso":"\033[31m","reset":"\033[0m"}
    return f"{colors.get(name,'')}{text}{colors['reset']}"
