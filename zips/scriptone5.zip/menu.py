# -*- coding: utf-8 -*-
from __future__ import annotations
import traceback

from util import input_int, ensure_path, color
from config import get_setting
from memento_import import memento_import_batch
from memento_sdk import (
    list_libraries,
    infer_field_mapping,
    show_one_raw_entry,
    import_library_auto,
)

def main_menu():
    while True:
        print("------ MEMENTO --------")
        print("1) Elenca librerie (SDK)")
        print("2) Deduci mappatura campi (SDK)")
        print("3) Mostra 1 entry grezza (SDK)")
        print("4) Importa libreria (auto)")
        print("5) Importa batch da YAML")
        print("0) Indietro / Esci")
        sel = input_int("> ")
        if sel == 0:
            return
        try:
            if sel == 1:
                _do_list_libs()
            elif sel == 2:
                _do_infer_mapping()
            elif sel == 3:
                _do_show_one_raw()
            elif sel == 4:
                _do_import_library_auto()
            elif sel == 5:
                _menu_import_batch()
            else:
                print("Selezione non valida.")
        except Exception as e:
            print(color("rosso", f"Errore: {e}"))
            traceback.print_exc()

def _menu_import_batch():
    db_default = get_setting("database.path", "")
    yml_default = get_setting("memento.yaml_batch_path", "")
    db_in = input(f"Percorso DB sqlite [{db_default}]: ").strip() or db_default
    yml_in = input(f"Percorso YAML [{yml_default}]: ").strip() or yml_default
    # Risolvi i path (il resolver guarda CWD, cartella entry-point, parent, cartella modulo)
    db_path = ensure_path(db_in, should_exist=False, kind="file")
    yml_path = ensure_path(yml_in, should_exist=True, kind="file")

    print("\n============== MEMENTO – Import batch da YAML ==============")
    memento_import_batch(db_path, yml_path)
    print(color("verde", "\nImport completato."))

def _do_list_libs():
    print("\n============== MEMENTO – Elenco librerie ==============")
    libs = list_libraries()
    for i, lib in enumerate(libs, 1):
        print(f"{i:>2}) {lib.get('id','?')}  {lib.get('name','')}")

def _do_infer_mapping():
    print("\n============== MEMENTO – Deduci mappatura campi ==============")
    lib = input(f"Library ID (invio=default): ").strip() or get_setting("memento.default_library_id", "")
    form = input("Form/Collection ID (opzionale): ").strip() or None
    mapping = infer_field_mapping(lib, form)
    print("Campo → Tipo (dedotto)")
    for k, v in mapping.items():
        print(f"- {k}: {v}")

def _do_show_one_raw():
    print("\n============== MEMENTO – Mostra 1 entry grezza ==============")
    lib = input(f"Library ID (invio=default): ").strip() or get_setting("memento.default_library_id", "")
    form = input("Form/Collection ID (opzionale): ").strip() or None
    entry = show_one_raw_entry(lib, form)
    print(entry)

def _do_import_library_auto():
    print("\n============== MEMENTO – Import libreria (auto) ==============")
    lib = input(f"Library ID (invio=default): ").strip() or get_setting("memento.default_library_id", "")
    db_in = input(f"Percorso DB sqlite [{get_setting('database.path','')}]: ").strip() or get_setting("database.path","")
    db_path = ensure_path(db_in, should_exist=False, kind="file")
    n = import_library_auto(db_path, lib)
    print(color("verde", f"Righe importate/aggiornate: {n}"))
