import os
import re
from typing import Any, Dict, List, Optional, Tuple

import requests
import yaml

_SETTINGS_PATHS = (
    "./settings.yaml",
    "settings.yaml",
    os.path.join(os.path.dirname(__file__), "settings.yaml"),
)

# ---------- settings & http ----------

def _load_settings() -> Dict[str, Any]:
    for p in _SETTINGS_PATHS:
        if os.path.exists(p):
            with open(p, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}
    return {}

def _api(path: str) -> str:
    s = _load_settings()
    base = s.get("memento", {}).get("api_url") or "https://api.mementodatabase.com"
    return base.rstrip("/") + path

def _headers() -> Dict[str, str]:
    s = _load_settings()
    token = s.get("memento", {}).get("token") or ""
    h = {"Accept": "application/json"}
    if token:
        h["Authorization"] = f"Bearer {token}"
    return h

def _raise_on_404(r: requests.Response, endpoint: str) -> None:
    if r.status_code == 404:
        raise RuntimeError(
            f"Memento Cloud API ha risposto 404 su {endpoint}. "
            "Possibili cause: token non valido, Cloud API non abilitata per l'account, "
            "oppure endpoint differente. Verifica 'memento.api_url' e 'memento.token' in settings.yaml."
        )
    r.raise_for_status()

# ---------- public SDK used by menu ----------

def list_libraries() -> List[Dict[str, Any]]:
    url = _api("/libraries")
    r = requests.get(url, headers=_headers(), timeout=20)
    _raise_on_404(r, "/libraries")
    data = r.json()
    # Expect either {'items':[...]} or list
    if isinstance(data, dict) and "items" in data and isinstance(data["items"], list):
        return data["items"]
    if isinstance(data, list):
        return data
    return []

def get_library(library_id: str) -> Dict[str, Any]:
    url = _api(f"/libraries/{library_id}")
    r = requests.get(url, headers=_headers(), timeout=20)
    _raise_on_404(r, f"/libraries/{library_id}")
    return r.json()

def get_library_entries(library_id: str, limit: int = 1) -> List[Dict[str, Any]]:
    url = _api(f"/libraries/{library_id}/entries")
    params = {"limit": str(limit)}
    r = requests.get(url, headers=_headers(), params=params, timeout=30)
    _raise_on_404(r, f"/libraries/{library_id}/entries")
    data = r.json()
    # Expect either {'items':[...]} or list
    if isinstance(data, dict) and "items" in data and isinstance(data["items"], list):
        return data["items"]
    if isinstance(data, list):
        return data
    return []

def get_one_raw_entry(library_id: str) -> Optional[Dict[str, Any]]:
    rows = get_library_entries(library_id, limit=1)
    return rows[0] if rows else None

# ---------- inference helpers ----------

_TEMPO_CANDIDATES = [
    "tempo", "time", "date", "datetime", "when", "timestamp",
    "created", "createdtime", "modified", "modifiedtime",
    "createdTime", "modifiedTime",
]

def _normalize(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", s.lower())

def infer_field_mapping(library: Any) -> Dict[str, Any]:
    """Infer a minimal mapping (tempo_col, id_mode) from a library JSON or id."""
    if isinstance(library, str):
        lib = get_library(library)
    else:
        lib = library or {}

    # Try to inspect fields metadata if present
    fields = []
    for key in ("fields", "columns", "schema"):
        v = lib.get(key)
        if isinstance(v, list):
            fields = v
            break

    tempo_col = None
    if fields:
        names = []
        for f in fields:
            if isinstance(f, dict):
                for k in ("name", "title", "label", "id"):
                    if k in f and isinstance(f[k], str):
                        names.append(f[k])
                        break
        norm = {n: _normalize(n) for n in names}
        for n, nn in norm.items():
            if nn in { _normalize(c) for c in _TEMPO_CANDIDATES }:
                tempo_col = n
                break

    if tempo_col is None:
        # fallback
        tempo_col = "tempo"

    mapping = {
        "tempo_col": tempo_col,
        "id_mode": "id",  # default safest
    }
    return mapping

# ---------- auto import (optional) ----------

def import_library_auto(db_path: str, library_id: str, table: Optional[str] = None, id_mode: str = "id") -> Dict[str, Any]:
    """Fetch entries from a library and import them into SQLite table.
    NOTE: This requires Cloud API access; otherwise it raises a clear error.
    """
    from memento_import import _import_entries  # local import to avoid circular at import time

    lib = get_library(library_id)
    name = table or lib.get("name") or lib.get("title") or f"memento_{library_id}"
    mapping = infer_field_mapping(lib)
    tempo_col = mapping.get("tempo_col") or "tempo"

    # naive paged fetch (first page only unless 'next' is available and enabled)
    entries = get_library_entries(library_id, limit=100)

    # connect and import
    import sqlite3, os
    if not db_path:
        db_path = "noutput.db"
    if not os.path.isabs(db_path):
        db_path = os.path.abspath(db_path)

    conn = sqlite3.connect(db_path)
    try:
        inserted, seen = _import_entries(conn, name, entries, id_mode, tempo_col)
        return {"table": name, "inserted": inserted, "seen": seen, "tempo_col": tempo_col}
    finally:
        conn.close()
