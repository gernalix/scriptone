import os
import json
import sqlite3
from typing import Any, Dict, List, Optional, Tuple, Iterable

try:
    import yaml
except ImportError:
    yaml = None

from db_utils import quote_ident, table_columns, ensure_ext_col_migrated, ensure_table_basic


# ================== INTERNAL HELPERS ==================

def _ensure_table_columns(conn: sqlite3.Connection, table: str) -> None:
    """Ensure standard columns commonly used by Memento imports exist."""
    desired = {
        "raw": "TEXT",
        "createdTime": "TEXT",
        "modifiedTime": "TEXT",
        "createdTime_remote": "TEXT",
        "modifiedTime_remote": "TEXT",
    }
    cols = table_columns(conn, table)
    for col, coltype in desired.items():
        if col not in cols:
            conn.execute(
                f"ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(col)} {coltype}"
            )
    conn.commit()


def _insert_rows(conn: sqlite3.Connection, table: str, rows: List[Dict[str, Any]]) -> int:
    """Insert payload rows into table. Missing columns are auto-created as TEXT."""
    if not rows:
        return 0

    cols_in_table = table_columns(conn, table)
    all_keys = set().union(*(row.keys() for row in rows))
    missing = [k for k in all_keys if k not in cols_in_table]
    for k in missing:
        conn.execute(f'ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(k)} TEXT')
    conn.commit()

    ordered_cols = sorted(all_keys)
    placeholders = ", ".join(["?"] * len(ordered_cols))
    collist = ", ".join(quote_ident(c) for c in ordered_cols)

    inserted = 0
    with conn:
        for row in rows:
            values = [row.get(c) for c in ordered_cols]
            conn.execute(
                f'INSERT OR IGNORE INTO {quote_ident(table)} ({collist}) VALUES ({placeholders})',
                values,
            )
            inserted += 1
    return inserted


def _import_entries(
    conn: sqlite3.Connection,
    table: str,
    entries: List[Dict[str, Any]],
    id_mode: str,
    tempo_col: Optional[str],
) -> Tuple[int, int]:
    """Import a batch of entries into table."""
    ensure_table_basic(conn, table, tempo_col or "tempo")
    ext_col = ensure_ext_col_migrated(conn, table)
    _ensure_table_columns(conn, table)

    if not entries:
        return (0, 0)

    rows: List[Dict[str, Any]] = []
    for e in entries:
        row: Dict[str, Any] = dict(e)

        # derive ext_id
        if id_mode == "id":
            row[ext_col] = str(e.get("id") or e.get("_id") or "")
        elif id_mode == "uuid":
            row[ext_col] = str(e.get("uuid") or "")
        elif id_mode == "hash":
            import hashlib, json as _json
            row[ext_col] = hashlib.sha1(
                _json.dumps(e, sort_keys=True).encode("utf-8")
            ).hexdigest()
        else:
            row[ext_col] = str(e.get("id") or "")

        # raw payload
        row.setdefault("raw", json.dumps(e, ensure_ascii=False))
        rows.append(row)

    inserted = _insert_rows(conn, table, rows)
    return (inserted, len(entries))


# ================== YAML LOADERS ==================

def _load_yaml(yml_path: Optional[str]) -> Any:
    """Load a YAML document with batches."""
    path = yml_path or "memento_import.yaml"
    if not os.path.isabs(path):
        path = os.path.abspath(path)

    if yaml is None:
        raise RuntimeError(
            "PyYAML non installato: impossibile leggere il file YAML. "
            "Esegui 'pip install pyyaml' per abilitarlo."
        )

    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def _iter_batches(doc: Any) -> Iterable[Dict[str, Any]]:
    """Yield normalized batches from YAML."""
    if isinstance(doc, dict) and "batches" in doc:
        doc = doc["batches"]

    if isinstance(doc, list):
        for item in doc:
            if not isinstance(item, dict):
                continue
            table = item.get("table") or item.get("name") or item.get("dest") or "unknown"
            entries = item.get("entries") or []
            id_mode = (item.get("id_mode") or "id").lower()
            tempo_col = item.get("tempo_col") or item.get("tempo") or "tempo"
            yield {
                "table": table,
                "entries": entries,
                "id_mode": id_mode,
                "tempo_col": tempo_col,
            }

    elif isinstance(doc, dict):
        for table, cfg in doc.items():
            if not isinstance(cfg, dict):
                continue
            entries = cfg.get("entries") or []
            id_mode = (cfg.get("id_mode") or "id").lower()
            tempo_col = cfg.get("tempo_col") or cfg.get("tempo") or "tempo"
            yield {
                "table": table,
                "entries": entries,
                "id_mode": id_mode,
                "tempo_col": tempo_col,
            }


# ================== MAIN ENTRY POINT ==================

def memento_import_batch(db_path: Optional[str], yml_path: Optional[str]) -> None:
    """Entry point used by menu.py (option 5)."""
    if not db_path:
        db_path = "noutput.db"
    if not os.path.isabs(db_path):
        db_path = os.path.abspath(db_path)

    doc = _load_yaml(yml_path)
    batches = list(_iter_batches(doc))

    if not batches:
        print("[MEMENTO] Nessun batch trovato nello YAML.")
        return

    conn = sqlite3.connect(db_path)
    try:
        total_inserted = 0
        total_seen = 0
        print("============== MEMENTO – Import batch da YAML ==============")
        for b in batches:
            table = b["table"]
            entries = b.get("entries") or []
            id_mode = b.get("id_mode") or "id"
            tempo_col = b.get("tempo_col") or "tempo"
            try:
                ins, seen = _import_entries(conn, table, entries, id_mode, tempo_col)
                total_inserted += ins
                total_seen += seen
                print(f"[ok] {table}: {ins}/{seen} righe importate")
            except Exception as e:
                print(f"[errore] {table}: {e}")
        print(f"[TOT] inserite {total_inserted}/{total_seen} righe")
    finally:
        conn.close()
