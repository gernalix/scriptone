# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, yaml
from typing import Optional

_SETTINGS_CACHE = None

def _candidate_paths(explicit: Optional[str]=None):
    """
    Ordine di ricerca:
    1) Variabile env SCRIPTONE_SETTINGS (se presente)
    2) Path esplicito passato alla funzione
    3) CWD
    4) Cartella del file chiamante (entry point) e sua parent
    5) Cartella di questo modulo (config.py)
    """
    env = os.environ.get("SCRIPTONE_SETTINGS")
    if env:
        yield env
    if explicit:
        yield explicit
    # 3) CWD
    yield os.path.abspath("settings.yaml")
    # 4) cartella del file chiamante / entry point
    try:
        # __main__ può avere __file__ quando avviato da file
        import __main__
        if hasattr(__main__, "__file__"):
            main_dir = os.path.dirname(os.path.abspath(__main__.__file__))
            yield os.path.join(main_dir, "settings.yaml")
            yield os.path.join(os.path.dirname(main_dir), "settings.yaml")
    except Exception:
        pass
    # 5) cartella di questo modulo
    here = os.path.dirname(os.path.abspath(__file__))
    yield os.path.join(here, "settings.yaml")

def _resolve_settings_path(path: Optional[str]) -> str:
    for p in _candidate_paths(path):
        if p and os.path.exists(p):
            return p
    # Non trovato -> messaggio con i candidati per debug
    tried = "\n - ".join(list(_candidate_paths(path)))
    raise FileNotFoundError(f"File di impostazioni non trovato. Percorsi verificati:\n - {tried}")

def load_settings(path: str = "settings.yaml") -> dict:
    global _SETTINGS_CACHE
    if _SETTINGS_CACHE is not None:
        return _SETTINGS_CACHE
    resolved = _resolve_settings_path(path)
    with open(resolved, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    _SETTINGS_CACHE = data
    return data

def get_setting(key_path: str, default=None):
    cur = load_settings()
    for part in key_path.split("."):
        if isinstance(cur, dict) and part in cur:
            cur = cur[part]
        else:
            return default
    return cur
