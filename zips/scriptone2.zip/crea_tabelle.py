# -*- coding: utf-8 -*-
# crea_tabelle.py — versione v13:
# - Import da Memento senza pandas
# - Lookup libreria robusto (URL/slug, id, name/title, regex, repr/str) con SDK
# - Fallback HTTP diretto all’API ufficiale (come nei notebook)
# - Risoluzione campi con regex + fallback per tipo
# - Deduplica (memento_id/csv_key) + id AUTOINCREMENT
# - Stampa "X righe importate da cloud/csv"

import sys
import sqlite3
from pathlib import Path
import re
from typing import List, Tuple, Optional, Dict
import yaml
import hashlib
import csv
from datetime import datetime, timezone
import json as _json

__CREA_TABELLE_VERSION__ = 'v13'

# Percorsi
HERE = Path(__file__).resolve().parent
DB_PATH = HERE / "noutput.db"
TRIGGERS_PATH = HERE / "triggers.sql"
CONFIG_PATH = HERE / "crea_tabelle.config.json"
MEMENTO_YAML = HERE / "memento_import.yaml"

REOPEN_PER_ACTION = False

# --------------------------- Utilità console ---------------------------

def pause(msg: str = "\nPremi Invio per uscire..."):
    try:
        input(msg)
    except EOFError:
        pass

def print_header(title: str):
    line = "=" * 64
    print(f"\n{line}\n{title}\n{line}")

def ask(prompt: str) -> str:
    try:
        return input(prompt)
    except EOFError:
        return ""

def mode_label() -> str:
    return "PER-AZIONE (riuso=NO)" if REOPEN_PER_ACTION else "RIUSO (riuso=SÌ)"

# --------------------------- Config persistence ---------------------------

def load_config() -> dict:
    try:
        return _json.loads(CONFIG_PATH.read_text(encoding="utf-8")) if CONFIG_PATH.exists() else {}
    except Exception:
        return {}

def save_config(cfg: dict) -> None:
    try:
        CONFIG_PATH.write_text(_json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception as e:
        print(f"[WARN] Impossibile salvare {CONFIG_PATH.name}: {e}")

def _init_mode_from_config():
    global REOPEN_PER_ACTION
    cfg = load_config()
    if isinstance(cfg.get("reopen_per_action"), bool):
        REOPEN_PER_ACTION = cfg["reopen_per_action"]

# --------------------------- DB helpers ---------------------------

def connect_db() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA recursive_triggers = ON;")
    return conn

def _table_exists(conn: sqlite3.Connection, name: str) -> bool:
    row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (name,)).fetchone()
    return bool(row)

def _get_table_cols(conn: sqlite3.Connection, table: str) -> list[str]:
    try:
        rows = conn.execute(f"PRAGMA table_info('{table}')").fetchall()
        return [r["name"] for r in rows]
    except sqlite3.OperationalError:
        return []

def _migrate_umore_schema(conn: sqlite3.Connection) -> None:
    cols = _get_table_cols(conn, "umore")
    need_migration = False
    if cols:
        needed = {"id","tempo","umore","memento_id","csv_key"}
        if not set(needed).issubset(set(cols)):
            need_migration = True
    if not cols or not need_migration:
        return
    conn.execute("""
        CREATE TABLE IF NOT EXISTS umore_new (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            tempo       TEXT NOT NULL,
            umore       INTEGER,
            memento_id  TEXT UNIQUE,
            csv_key     TEXT UNIQUE
        )
    """)
    sel_cols = [c for c in cols if c in ("tempo","umore","memento_id","csv_key")]
    if not sel_cols:
        sel_cols = ["tempo","umore"]
    select_list = ", ".join(sel_cols)
    insert_list = ", ".join(sel_cols)
    conn.execute(f"INSERT INTO umore_new ({insert_list}) SELECT {select_list} FROM umore")
    conn.execute("DROP TABLE umore")
    conn.execute("ALTER TABLE umore_new RENAME TO umore")
    conn.commit()
    print("[migrate] Tabella 'umore' migrata a schema con id AUTOINCREMENT + vincoli UNIQUE.")

def _ensure_umore_table(conn: sqlite3.Connection) -> None:
    if not _table_exists(conn, "umore"):
        conn.execute("""
            CREATE TABLE IF NOT EXISTS umore (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                tempo       TEXT NOT NULL,
                umore       INTEGER,
                memento_id  TEXT UNIQUE,
                csv_key     TEXT UNIQUE
            )
        """)
        return
    _migrate_umore_schema(conn)

# --------------------------- YAML helpers ---------------------------

def _load_yaml(path: Path) -> dict:
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def _save_yaml(path: Path, data: dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        yaml.safe_dump(data, f, allow_unicode=True, sort_keys=False)

def _default_memento_settings() -> dict:
    return {
        "token": "VU2rRi7hXdmlj9I4hu6BaRg1XMMxlM",
        "library_name": "umore",
        "library_address": "https://mementodb.com/s/wn8JsQymR",
        "library_id": "TdQ7qjQdK",   # <-- dai tuoi notebook
        "dest_table": "umore",
        "columns": {"tempo": "tempo", "umore": "umore"},
        "csv_fallback": "umore.csv",
        "time": {
            "csv_input_format": "%d/%m/%Y %H:%M:%S",
            "sqlite_output_format": "%Y-%m-%d %H:%M:%S",
            "assume_tz": "UTC"
        },
        # opzionali:
        # "library_regex": "umore|wn8JsQymR",
        # "tempo_field_regex": "(^|\\b)tempo(\\b|$)",
        # "umore_field_regex": "(^|\\b)umore(\\b|$)",
        # "base_url": "https://api.mementodatabase.com/v1"
    }

def _load_or_init_memento_yaml() -> dict:
    cfg = _load_yaml(MEMENTO_YAML)
    if not cfg:
        cfg = _default_memento_settings()
        _save_yaml(MEMENTO_YAML, cfg)
        print(f"[setup] Creato {MEMENTO_YAML.name} con impostazioni predefinite.")
    return cfg

# --------------------------- Tempo & chiavi ---------------------------

def _sqlite_time_str(dt_obj: datetime) -> str:
    if dt_obj.tzinfo is not None:
        dt_obj = dt_obj.astimezone(timezone.utc).replace(tzinfo=None)
    return dt_obj.strftime("%Y-%m-%d %H:%M:%S")

def _parse_csv_tempo(s: str, fmt: str) -> datetime:
    return datetime.strptime(s, fmt)

def make_csv_key(tempo_str: str, umore_val) -> str:
    raw = f"{tempo_str}|{'' if umore_val is None else int(umore_val)}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()

# --------------------------- Discovery libreria via SDK (best effort) ---------------------------

import re as _re

def _discover_memento_library(server, cfg):
    """Best effort con SDK; se fallisce useremo HTTP diretto."""
    try:
        libs = server.list_libraries()
    except Exception:
        return None
    if not libs:
        return None

    def _norm(x):
        return _re.sub(r"\s+", " ", str(x)).strip().lower() if x is not None else None

    # 1) library_id esplicito
    lib_id = cfg.get("library_id")
    if lib_id:
        for lib in libs:
            try:
                if str(getattr(lib, "id", "")) == str(lib_id):
                    return lib
            except Exception:
                pass

    # 2) slug da address
    addr = cfg.get("library_address")
    if addr:
        slug = addr.rstrip("/").split("/")[-1]
        for lib in libs:
            try:
                for attr in ("address","url","share_url","public_url","short_url","path"):
                    val = getattr(lib, attr, None)
                    if isinstance(val, str) and slug in val:
                        return lib
                if slug == str(getattr(lib, "id", "")):
                    return lib
            except Exception:
                pass

    # 3) title/name
    goal = _norm(cfg.get("library_name", "umore"))
    if goal:
        for lib in libs:
            try:
                cand = {_norm(getattr(lib, "title", None)), _norm(getattr(lib, "name", None))}
                if goal in cand:
                    return lib
            except Exception:
                pass

    # 4) regex libera
    reg = cfg.get("library_regex")
    if reg:
        try:
            rx = _re.compile(reg, _re.I)
            for lib in libs:
                try:
                    if rx.search(repr(lib)[:1000] or "") or rx.search(str(lib)[:1000] or ""):
                        return lib
                except Exception:
                    pass
        except Exception:
            pass

    return None

# --------------------------- Risoluzione campi (tollerante) ---------------------------

def _norm(s):
    return _re.sub(r"\s+", " ", str(s)).strip().lower() if s is not None else None

def _collect_field_meta(lib):
    out = []
    for f in getattr(lib, "fields", []):
        meta = {
            "id": getattr(f, "id", None),
            "name": getattr(f, "name", None),
            "title": getattr(f, "title", None),
            "label": getattr(f, "label", None),
            "type": getattr(f, "type", None) or getattr(f, "field_type", None) or getattr(f, "kind", None),
        }
        out.append(meta)
    return out

def _print_fields_diag(fields):
    print("[diag] Campi visibili nella libreria:")
    for m in fields:
        print(f"  - id={m['id']}, name={m['name']}, title={m['title']}, label={m['label']}, type={m['type']}")

def _resolve_field_id(fields, want_regex: str | None, want_name: str | None, want_role: str) -> str | None:
    # 1) Regex esplicita
    if want_regex:
        try:
            rx = _re.compile(want_regex, _re.I)
        except Exception:
            rx = None
        if rx:
            for m in fields:
                hay = " ".join([str(m.get("name") or ""), str(m.get("title") or ""), str(m.get("label") or "")])
                if rx.search(hay):
                    return m.get("id")

    # 2) Match morbido su name/title/label
    want = _norm(want_name) if want_name else None
    if want:
        for m in fields:
            cand = {_norm(m.get("name")), _norm(m.get("title")), _norm(m.get("label"))}
            if want in cand:
                return m.get("id")

    # 3) Fallback per tipo
    time_types = {"datetime", "date/time", "date_time", "date", "time", "timestamp"}
    rating_types = {"rating", "number", "integer", "int", "float", "double", "numeric", "status"}

    if want_role == "tempo":
        for m in fields:
            t = _norm(m.get("type"))
            if t in time_types:
                return m.get("id")
        for m in fields:
            hay = " ".join([_norm(m.get("name")), _norm(m.get("title")), _norm(m.get("label"))])
            if hay and ("tempo" in hay or "time" in hay or "date" in hay):
                return m.get("id")

    if want_role == "umore":
        for m in fields:
            t = _norm(m.get("type"))
            if t in rating_types:
                return m.get("id")
        for m in fields:
            hay = " ".join([_norm(m.get("name")), _norm(m.get("title")), _norm(m.get("label"))])
            if hay and ("umore" in hay or "mood" in hay or "rating" in hay or "score" in hay or "status" in hay):
                return m.get("id")

    return None

# --------------------------- Importers ---------------------------

def import_umore_from_csv(conn: sqlite3.Connection, cfg: dict) -> int:
    csv_path = HERE / cfg.get("csv_fallback","umore.csv")
    if not csv_path.exists():
        print(f"[WARN] CSV di fallback non trovato: {csv_path}")
        return 0
    _ensure_umore_table(conn)
    fmt = cfg.get("time",{}).get("csv_input_format","%d/%m/%Y %H:%M:%S")
    count = 0
    with open(csv_path,"r",encoding="utf-8",newline="") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or "tempo" not in reader.fieldnames or "umore" not in reader.fieldnames:
            print("[ERRORE] CSV non contiene colonne richieste 'tempo' e 'umore'.")
            return 0
        for row in reader:
            try:
                t = _parse_csv_tempo(row["tempo"], fmt)
                t_str = _sqlite_time_str(t)
                u = None if row["umore"] in ("","NaN",None) else int(row["umore"])
                key = make_csv_key(t_str, u)
                conn.execute(
                    "INSERT INTO umore(tempo, umore, csv_key) VALUES(?,?,?) "
                    "ON CONFLICT(csv_key) DO NOTHING",
                    (t_str, u, key)
                )
                if conn.total_changes:
                    count += 1
            except Exception as e:
                print(f"[SKIP] Riga non importata ({e}): {row}")
    conn.commit()
    print(f"{count} righe importate da csv")
    return count

# === NEW: HTTP client diretto all'API Memento (come nei notebook) ===
def _http_fetch_all_entries(base_url: str, lib_id: str, token: str, include_fields: bool = True, page_size: int = 500) -> list:
    import requests
    api_url = f"{base_url}/libraries/{lib_id}/entries"
    params_base = {"token": token}
    if include_fields:
        params_base["include"] = "fields"

    all_items, seen_ids = [], set()

    def _append(items):
        for it in items:
            _id = it.get("id")
            if _id is None or _id in seen_ids:  # de-dup
                continue
            seen_ids.add(_id)
            all_items.append(it)

    # Strategy A: offset/limit
    offset = 0
    fetched_A = 0
    while True:
        try:
            r = requests.get(api_url, params={**params_base, "offset": offset, "limit": page_size}, timeout=30)
            if r.status_code != 200:
                break
            data = r.json()
            items = []
            if isinstance(data, dict):
                for k in ("entries","items","records","data","result"):
                    v = data.get(k)
                    if isinstance(v, list):
                        items = v
                        break
            elif isinstance(data, list):
                items = data
            _append(items)
            fetched_A += 1
            if not items or len(items) < page_size:
                break
            offset += page_size
        except Exception:
            break

    # Se abbiamo preso solo 1 pagina piena, proviamo page/pageSize
    if fetched_A == 1 and len(all_items) == page_size:
        all_items, seen_ids = [], set()
        page = 1
        while True:
            try:
                r = requests.get(api_url, params={**params_base, "page": page, "pageSize": page_size}, timeout=30)
                if r.status_code != 200:
                    break
                data = r.json()
                items = []
                if isinstance(data, dict):
                    for k in ("entries","items","records","data","result"):
                        v = data.get(k)
                        if isinstance(v, list):
                            items = v
                            break
                elif isinstance(data, list):
                    items = data
                _append(items)
                if not items or len(items) < page_size:
                    break
                page += 1
            except Exception:
                break

    return all_items

def _http_entry_details(base_url: str, lib_id: str, entry_id: str, token: str) -> dict:
    """Ritorna dict con 'fields' e 'values' se possibile."""
    import requests
    url = f"{base_url}/libraries/{lib_id}/entries/{entry_id}"
    common = {"token": token}
    for inc in ["fields,values", "fields", "values", "all"]:
        try:
            r = requests.get(url, params={**common, "include": inc}, timeout=30)
            if r.status_code == 200:
                data = r.json()
                if isinstance(data, dict) and (data.get("fields") or data.get("values")):
                    return data
        except Exception:
            pass
    # fallback: senza include
    try:
        r = requests.get(url, params=common, timeout=30)
        if r.status_code == 200:
            return r.json()
    except Exception:
        pass
    return {}

def _http_resolve_columns_from_fields(fields_meta: list[dict], cfg: dict) -> tuple[Optional[str], Optional[str], dict]:
    """Ritorna (tempo_field_id, umore_field_id, id_to_name_map)."""
    # fields_meta è tipicamente una lista di oggetti con id, name/title/label e type
    # Costruisci id_to_name
    id_to_name = {}
    for f in fields_meta or []:
        fid = f.get("id")
        nm = f.get("name") or f.get("title") or f.get("label")
        if fid:
            id_to_name[str(fid)] = str(nm) if nm is not None else None

    # Risoluzione robusta come sopra (regex + tipo)
    def pick_field_id(role: str) -> Optional[str]:
        want_regex = cfg.get(f"{role}_field_regex")
        want_name = cfg.get("columns", {}).get(role, role)
        # 1) regex
        if want_regex:
            try:
                rx = _re.compile(want_regex, _re.I)
            except Exception:
                rx = None
            if rx:
                for f in fields_meta or []:
                    hay = " ".join([str(f.get("name") or ""), str(f.get("title") or ""), str(f.get("label") or "")])
                    if rx.search(hay):
                        return str(f.get("id"))
        # 2) match morbido
        wn = _norm(want_name)
        if wn:
            for f in fields_meta or []:
                cand = {_norm(f.get("name")), _norm(f.get("title")), _norm(f.get("label"))}
                if wn in cand:
                    return str(f.get("id"))
        # 3) tipo
        if role == "tempo":
            time_types = {"datetime", "date/time", "date_time", "date", "time", "timestamp"}
            for f in fields_meta or []:
                t = _norm(f.get("type"))
                if t in time_types:
                    return str(f.get("id"))
        if role == "umore":
            rating_types = {"rating", "number", "integer", "int", "float", "double", "numeric", "status"}
            for f in fields_meta or []:
                t = _norm(f.get("type"))
                if t in rating_types:
                    return str(f.get("id"))
        return None

    return pick_field_id("tempo"), pick_field_id("umore"), id_to_name

def import_umore_from_memento_http(conn: sqlite3.Connection, cfg: dict) -> int:
    """Fallback HTTP diretto (come nei notebook)."""
    token = cfg.get("token")
    lib_id = cfg.get("library_id") or "TdQ7qjQdK"
    base_url = cfg.get("base_url") or "https://api.mementodatabase.com/v1"

    if not token:
        print("[ERRORE] Token mancante in YAML.")
        return 0

    # 1) prendi tutte le entries (lista)
    entries = _http_fetch_all_entries(base_url, lib_id, token, include_fields=True, page_size=500)
    if not entries:
        print("[diag] Nessuna entry visibile via HTTP per la libreria indicata.")
        return 0

    # 2) prendi il dettaglio della prima entry per raccogliere i meta 'fields' -> mappa id->name
    first_id = entries[0].get("id")
    meta = _http_entry_details(base_url, lib_id, first_id, token) if first_id else {}
    fields_meta = meta.get("fields") or []  # di solito list di dict
    tempo_fid, umore_fid, id_to_name = _http_resolve_columns_from_fields(fields_meta, cfg)

    if not tempo_fid or not umore_fid:
        # Prova a cercare anche nella risposta della lista (a volte include i fields)
        list_fields = None
        if isinstance(entries, list) and entries:
            lf = entries[0].get("fields") or entries[0].get("meta") or None
            if isinstance(lf, list):
                list_fields = lf
        if list_fields:
            tempo_fid, umore_fid, id_to_name = _http_resolve_columns_from_fields(list_fields, cfg)

    if not tempo_fid or not umore_fid:
        print("[ERRORE] Non riesco a risolvere gli id dei campi 'tempo'/'umore' via HTTP.")
        return 0

    # 3) importa tutte le entry: per ciascuna, leggi values (se non presenti nella lista, fai dettaglio)
    _ensure_umore_table(conn)
    inserted = 0
    fmt_csv = cfg.get("time",{}).get("csv_input_format","%d/%m/%Y %H:%M:%S")

    for e in entries:
        try:
            e_id = str(e.get("id"))
            values = e.get("values")
            if not isinstance(values, dict):
                # prendi dettaglio
                det = _http_entry_details(base_url, lib_id, e_id, token)
                values = det.get("values", {})
            if not isinstance(values, dict):
                continue

            # valori dei 2 campi
            t_val = values.get(str(tempo_fid))
            u_val = values.get(str(umore_fid))

            # normalizza tempo
            if isinstance(t_val, str):
                try:
                    dt_obj = datetime.fromisoformat(t_val.replace("Z","+00:00"))
                except Exception:
                    dt_obj = _parse_csv_tempo(t_val, fmt_csv)
            else:
                dt_obj = t_val
            if not isinstance(dt_obj, datetime):
                continue
            t_str = _sqlite_time_str(dt_obj)

            u_int = None
            if u_val not in (None, ""):
                try:
                    u_int = int(u_val)
                except Exception:
                    # rating potrebbe arrivare come dict o float/stringa
                    try:
                        u_int = int(float(str(u_val)))
                    except Exception:
                        u_int = None

            conn.execute(
                "INSERT INTO umore(tempo, umore, memento_id) VALUES(?,?,?) "
                "ON CONFLICT(memento_id) DO NOTHING",
                (t_str, u_int, e_id)
            )
            if conn.total_changes:
                inserted += 1
        except Exception as ex:
            print(f"[SKIP] Entry {e.get('id')} non importata: {ex}")

    conn.commit()
    print(f"{inserted} righe importate da cloud")
    return inserted

def import_umore_from_memento(conn: sqlite3.Connection, cfg: dict) -> int:
    """Prova SDK; se non espone meta, usa HTTP diretto."""
    # 1) tenta SDK (se c'è)
    try:
        from pymementodb import Memento
    except Exception:
        # niente SDK → vai diretto HTTP
        return import_umore_from_memento_http(conn, cfg)

    token = cfg.get("token")
    if not token:
        print("[ERRORE] Token mancante in YAML.")
        return 0

    # 2) tenta discovery libreria con SDK
    try:
        server = Memento(token)
    except Exception:
        return import_umore_from_memento_http(conn, cfg)

    lib = _discover_memento_library(server, cfg)
    if not lib:
        # SDK non “vede” i meta → HTTP
        return import_umore_from_memento_http(conn, cfg)

    # 3) prova a risolvere i campi via SDK (se li espone)
    fields = _collect_field_meta(lib)
    if not fields:
        # anche qui, se non espone, usa HTTP
        return import_umore_from_memento_http(conn, cfg)

    tempo_id = _resolve_field_id(fields, cfg.get("tempo_field_regex"), cfg.get("columns", {}).get("tempo", "tempo"), "tempo")
    umore_id = _resolve_field_id(fields, cfg.get("umore_field_regex"), cfg.get("columns", {}).get("umore", "umore"), "umore")
    if tempo_id is None or umore_id is None:
        return import_umore_from_memento_http(conn, cfg)

    # 4) leggi entries via SDK (se disponibile) — altrimenti HTTP
    try:
        entries = server.get_entries(getattr(lib, "id"), field_ids=[tempo_id, umore_id])
    except Exception:
        return import_umore_from_memento_http(conn, cfg)

    _ensure_umore_table(conn)
    inserted = 0
    for e in entries:
        try:
            t_val = e.get_field_value(tempo_id)
            u_val = e.get_field_value(umore_id)
            e_id  = str(getattr(e, "id", e))

            if isinstance(t_val, str):
                try:
                    dt_obj = datetime.fromisoformat(t_val.replace("Z","+00:00"))
                except Exception:
                    dt_obj = _parse_csv_tempo(t_val, cfg.get("time",{}).get("csv_input_format","%d/%m/%Y %H:%M:%S"))
            else:
                dt_obj = t_val
            t_str = _sqlite_time_str(dt_obj)
            u_int = int(u_val) if u_val not in (None,"") else None

            conn.execute(
                "INSERT INTO umore(tempo, umore, memento_id) VALUES(?,?,?) "
                "ON CONFLICT(memento_id) DO NOTHING",
                (t_str, u_int, e_id)
            )
            if conn.total_changes:
                inserted += 1
        except Exception as ex:
            print(f"[SKIP] Entry {getattr(e,'id','?')} non importata: {ex}")
    conn.commit()
    print(f"{inserted} righe importate da cloud")
    return inserted

def menu_importa_da_memento():
    print_header("Importa 'umore' da Memento Cloud")
    cfg = _load_or_init_memento_yaml()
    with connect_db() as conn:
        _ensure_umore_table(conn)
        n = import_umore_from_memento(conn, cfg)
        if n == 0:
            print("[info] Nessuna riga dal cloud. Provo CSV...")
            n = import_umore_from_csv(conn, cfg)
        print("[OK] Import completato.")

# --------------------------- Stub per funzioni menu (se mancanti) ---------------------------

def menu_aggiungi_tabella():
    print("[menu_aggiungi_tabella] (stub) — Sostituisci con la tua implementazione.")

def menu_modifica_tabella():
    print("[menu_modifica_tabella] (stub) — Sostituisci con la tua implementazione.")

# --------------------------- Main ---------------------------

def main():
    global REOPEN_PER_ACTION
    _init_mode_from_config()

    print_header("CREA/MODIFICA TABELLE + TRIGGER (noutput.db) — versione completa")
    print(f"Percorso DB: {DB_PATH}")
    print(f"Template trigger: {TRIGGERS_PATH}\n")

    while True:
        print(f"[INFO] Modalità connessione attiva: {mode_label()}")
        print("Seleziona un'azione:")
        print("  1) Aggiungi tabella")
        print("  2) Modifica tabella")
        print(f"  3) Cambia modalità connessione (ora: {mode_label()})")
        print("  4) Importa da Memento (umore)")
        print("  0) Esci")
        choice = ask("> ").strip()
        if choice == "1":
            menu_aggiungi_tabella()
        elif choice == "2":
            menu_modifica_tabella()
        elif choice == "3":
            REOPEN_PER_ACTION = not REOPEN_PER_ACTION
            cfg = load_config(); cfg["reopen_per_action"] = REOPEN_PER_ACTION; save_config(cfg)
            print(f"[OK] Modalità connessione impostata a: {mode_label()}")
        elif choice == "4":
            menu_importa_da_memento()
        elif choice == "0":
            print("Uscita.")
            break
        else:
            print("Scelta non valida.")

print(f"[crea_tabelle] versione: {__CREA_TABELLE_VERSION__} — python: {sys.version.split()[0]} — exe: {sys.executable}")

if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print("\n=== ERRORE NON GESTITO ===")
        print(f"{type(exc).__name__}: {exc}")
        import traceback
        traceback.print_exc()
        pause("\nPremi Invio per chiudere...")
        sys.exit(1)
    finally:
        pause()
