# -*- coding: utf-8 -*-
import os, re, json, time, requests, configparser
from typing import Any, Dict, List, Tuple

# =====================
# Config loader
# =====================
_CFG = None

def _load_cfg():
    global _CFG
    if _CFG is not None:
        return _CFG
    cfg = {}
    here = os.path.dirname(os.path.abspath(__file__))
    search_dirs = [here, os.getcwd(), os.path.dirname(here)]
    ini_paths = [os.path.join(d, "settings.ini") for d in search_dirs]
    yml_paths = [os.path.join(d, "settings.yaml") for d in search_dirs] + [os.path.join(d, "settings.yml") for d in search_dirs]
    # YAML first
    for p in yml_paths:
        if os.path.exists(p):
            try:
                import yaml
                with open(p, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
                for section, kv in (data or {}).items():
                    if isinstance(kv, dict):
                        for k, v in kv.items():
                            cfg[f"{section}.{k}"] = v
                _CFG = cfg
                return cfg
            except Exception:
                pass
    # INI fallback
    for p in ini_paths:
        if os.path.exists(p):
            try:
                cp = configparser.ConfigParser()
                cp.read(p, encoding="utf-8")
                for section in cp.sections():
                    for k, v in cp.items(section):
                        cfg[f"{section}.{k}"] = v
                _CFG = cfg
                return cfg
            except Exception:
                pass
    _CFG = cfg
    return cfg

def _cfg_get(key, default=None):
    return _load_cfg().get(key, default)

def _sanitize_url(url):
    return (url or "").strip()

def _timeout():
    try:
        return float(os.environ.get("MEMENTO_TIMEOUT", "30"))
    except Exception:
        return 30.0

def _base_url():
    url = _cfg_get("memento.api_url", "https://api.mementodatabase.com")
    url = _sanitize_url(url or "")
    if not url.endswith("/v1") and not url.endswith("/v1/"):
        url = url.rstrip("/") + "/v1"
    return url

def _token_params():
    token = _cfg_get("memento.token") or os.environ.get("MEMENTO_TOKEN")
    if not token:
        raise RuntimeError("Token Memento mancante: imposta 'memento.token' in settings.ini/.yaml oppure MEMENTO_TOKEN.")
    return {"token": token}

def _raise_on_404(r, path):
    if r.status_code == 404:
        raise RuntimeError(f"Memento API 404 su {path}\nURL: {r.request.method} {r.url}\nBody: {r.text[:400]}")
    r.raise_for_status()

# =====================
# HTTP with backoff
# =====================
def _get_with_backoff(url, *, params=None, timeout=None, max_tries=8, base_sleep=0.8, max_sleep=20.0):
    import random
    tries = 0
    while tries < max_tries:
        r = requests.get(url, params=params or {}, timeout=timeout or _timeout())
        if r.status_code < 400 or r.status_code in (400,401,403,404):
            return r
        if r.status_code == 429 or 500 <= r.status_code < 600:
            retry_after = r.headers.get("Retry-After")
            if retry_after:
                try:
                    sleep_s = float(retry_after)
                except Exception:
                    sleep_s = None
            else:
                sleep_s = min(max_sleep, base_sleep * (2 ** tries)) + random.uniform(0, 0.4)
            time.sleep(sleep_s or 1.0)
            tries += 1
            continue
        return r
    return r

# =====================
# Helpers
# =====================
def _extract_items(payload: Any) -> List[Any]:
    items = None
    if isinstance(payload, dict):
        items = payload.get("entries") or payload.get("items") or payload.get("results")
        if items is None and "data" in payload:
            items = payload["data"]
    if items is None:
        items = payload
    if isinstance(items, dict):
        items = list(items.values())
    return items if isinstance(items, list) else []

def _find_next(payload: Any, headers: Dict[str, str], params: Dict[str, Any], limit: int):
    # 1) explicit link in body
    if isinstance(payload, dict):
        for k in ("next", "next_url", "nextUrl"):
            nxt = payload.get(k)
            if isinstance(nxt, str) and nxt:
                return ("url", nxt)
        # 2) HAL-style links
        links = payload.get("links") or payload.get("_links") or {}
        if isinstance(links, dict):
            nxt = links.get("next")
            if isinstance(nxt, dict):
                href = nxt.get("href") or nxt.get("url")
                if href: return ("url", href)
        # 3) cursor-based
        for k in ("next_cursor", "nextCursor", "cursor"):
            cur = payload.get(k)
            if isinstance(cur, str) and cur:
                return ("cursor", cur)
        # 4) offset/total
        if ("offset" in payload) or ("total" in payload):
            try:
                off = int(payload.get("offset") or 0)
                tot = int(payload.get("total") or 0)
                return ("offset", (off, tot))
            except Exception:
                pass
        # 5) page/pages
        if ("page" in payload) or ("pages" in payload) or ("page_size" in payload):
            try:
                page = int(payload.get("page") or 1)
                pages = int(payload.get("pages") or 0)
                size = int(payload.get("page_size") or payload.get("per_page") or params.get("limit") or limit)
                return ("page", (page, pages, size))
            except Exception:
                pass
        # 6) has_more
        if payload.get("has_more") is True:
            return ("has_more", True)
    # 7) header-based
    hdr_next = headers.get("X-Next-Page") if headers else None
    if hdr_next:
        return ("page_header", hdr_next)
    return (None, None)

# =====================
# Main fetch
# =====================
def fetch_all_entries_full(library_id, limit=100):
    base = _base_url()
    url = f"{base}/libraries/{library_id}/entries"
    params = _token_params(); params["limit"] = int(limit)

    all_rows: List[Dict[str, Any]] = []
    page_guard = 0
    seen_sig = set()  # signatures to detect no-progress

    while True:
        r = _get_with_backoff(url, params=params, timeout=_timeout())
        _raise_on_404(r, f"/libraries/{library_id}/entries")
        data = r.json() if r.content else {}
        items = _extract_items(data)

        # normalize to dict rows (fetch detail if only ids)
        rows: List[Dict[str, Any]] = []
        for it in items:
            if isinstance(it, dict):
                rows.append(it)
            else:
                try:
                    eid = it if isinstance(it, (str,int)) else None
                    if eid is not None:
                        durl = f"{base}/libraries/{library_id}/entries/{eid}"
                        d = _get_with_backoff(durl, params=_token_params(), timeout=_timeout())
                        _raise_on_404(d, f"/libraries/{library_id}/entries/{eid}")
                        rows.append(d.json())
                except Exception:
                    continue

        all_rows.extend(rows)

        # try to find next
        kind, nxt = _find_next(data, r.headers, params, limit)
        if kind == "url" and nxt:
            url, params = nxt, {}
            continue
        elif kind == "cursor" and nxt:
            params = _token_params(); params["limit"] = int(limit); params["cursor"] = nxt
            continue
        elif kind == "offset":
            off, tot = nxt
            off = int(off or 0)
            step = len(items) if items else int(params.get("limit") or limit)
            new_off = off + step
            if tot and new_off >= tot:
                break
            params = _token_params(); params["limit"] = int(limit); params["offset"] = new_off
            continue
        elif kind == "page":
            page, pages, size = nxt
            next_page = int(page or 1) + 1
            if pages and next_page > pages:
                break
            params = _token_params(); params["limit"] = int(limit); params["page"] = next_page
            continue
        elif kind == "page_header":
            params = _token_params(); params["limit"] = int(limit); params["page"] = nxt
            continue
        elif kind == "has_more":
            step = len(items) if items else int(params.get("limit") or limit)
            prev_off = int(params.get("offset", 0))
            params = _token_params(); params["limit"] = int(limit); params["offset"] = prev_off + step
            continue

        # No explicit next: brute-force fallback
        # signature of current page to detect stalling
        sig = (len(items), tuple(sorted([tuple(sorted(x.keys())) for x in rows if isinstance(x, dict)])[:5]))
        if sig in seen_sig:
            break
        seen_sig.add(sig)

        if not items:
            break
        if len(items) < int(params.get("limit") or limit):
            break

        # Try offset, start, skip; also try page increasing
        tried = False
        last_params = dict(params)
        for key in ("offset","start","skip"):
            base_off = int(params.get(key, 0))
            params = _token_params(); params["limit"] = int(limit); params[key] = base_off + len(items)
            tried = True
            break
        if not tried:
            page = int(params.get("page", 1))
            params = _token_params(); params["limit"] = int(limit); params["page"] = page + 1

        page_guard += 1
        if page_guard > 1000:
            break

    return all_rows
