README PATCH — MEMENTO SDK
==========================

- Aggiunto percorso di default del database:
  Z:\download\datasette5\scriptone\noutput.db

Usalo così:
------------
from memento_sdk import get_default_db_path
print(get_default_db_path())

Oppure direttamente:
from memento_sdk import DEFAULT_DB_PATH
print(DEFAULT_DB_PATH)
