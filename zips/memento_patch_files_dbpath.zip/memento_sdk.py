import os
import re
import json
import time
import requests

# Percorso predefinito del database
DEFAULT_DB_PATH = r"Z:\download\datasette5\scriptone\noutput.db"

def get_default_db_path():
    """Restituisce il percorso di default del database SQLite locale."""
    return DEFAULT_DB_PATH

# ... (resto del codice invariato, come nella versione precedente) ...
