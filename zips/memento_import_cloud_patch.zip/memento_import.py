    # -*- coding: utf-8 -*-
    from __future__ import annotations
    from pathlib import Path
    import os, sqlite3, json, hashlib, configparser
    try:
        import yaml  # type: ignore
    except Exception:
        yaml = None

    from util import resolve_here
    import memento_sdk as sdk

    def _vprint(*args):
        if os.environ.get("MEMENTO_VERBOSE", "0") not in ("0",""):
            print(*args)

    def _cp_parser():
        return configparser.ConfigParser(
            interpolation=None,
            delimiters=('=',),
            comment_prefixes=('#',),  # ';' allowed in values
            strict=False,
        )

    def _load_batch_file(path: str):
        p = resolve_here(path)
        if not p.is_file():
            raise FileNotFoundError(f"File batch non trovato: {path}")
        suf = p.suffix.lower()
        if suf in (".yml", ".yaml"):
            if yaml is None:
                raise RuntimeError("PyYAML non disponibile (installa 'pyyaml')")
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
            return {"kind": "yaml", "data": data}
        if suf == ".ini":
            cp = _cp_parser()
            cp.read(p, encoding="utf-8")
            return {"kind": "ini", "cp": cp}
        raise ValueError(f"Estensione non supportata: {p.suffix}")

    def _row_ext_id(row: dict, id_mode: str) -> str:
        if id_mode == "id" and row.get("id"):
            return str(row["id"])
        payload = json.dumps(row, ensure_ascii=False, sort_keys=True)
        return hashlib.sha1(payload.encode("utf-8")).hexdigest()

    def _ensure_table(conn: sqlite3.Connection, table: str, tempo_col: str) -> None:
        cur = conn.cursor()
        cur.execute(f"CREATE TABLE IF NOT EXISTS {table} (id TEXT, ext_id TEXT UNIQUE, {tempo_col} TEXT, raw TEXT)")
        conn.commit()
        cur.close()

    def _insert_rows(conn: sqlite3.Connection, table: str, tempo_col: str, id_mode: str, rows: list) -> int:
        _ensure_table(conn, table, tempo_col)
        cur = conn.cursor()
        inserted = 0
        for e in rows:
            # normalize
            if "id" not in e:
                if "memento_id" in e: e["id"] = e["memento_id"]
                elif "ext_id" in e: e["id"] = e["ext_id"]
            ext = _row_ext_id(e, id_mode or "id")
            e["ext_id"] = ext
            # tempo
            if tempo_col not in e:
                # try common keys
                e[tempo_col] = e.get("tempo") or e.get("time") or e.get("timestamp") or e.get("createdTime") or e.get("created_at")
            # upsert (ignore duplicates by ext_id)
            cur.execute(f"SELECT 1 FROM {table} WHERE ext_id=?", (ext,))
            if cur.fetchone():
                continue
            cur.execute(f"INSERT OR IGNORE INTO {table} (id, ext_id, {tempo_col}, raw) VALUES (?,?,?,?)",
                        (e.get("id"), ext, e.get(tempo_col), json.dumps(e, ensure_ascii=False)))
            if cur.rowcount:
                inserted += 1
        conn.commit()
        cur.close()
        return inserted

    def _import_from_ini(conn: sqlite3.Connection, cp: configparser.ConfigParser) -> int:
        total = 0
        for sec in cp.sections():
            mode = (cp.get(sec, "mode", fallback="local") or "local").strip().lower()
            table = (cp.get(sec, "table", fallback=sec) or sec).strip()
            id_mode = (cp.get(sec, "id_mode", fallback="id") or "id").strip().lower()
            tempo_col = (cp.get(sec, "tempo_col", fallback="tempo") or "tempo").strip()

            if mode == "cloud":
                library_id = cp.get(sec, "library_id", fallback="").strip()
                form = (cp.get(sec, "form", fallback="default") or "default").strip()
                since = cp.get(sec, "since", fallback="").strip() or None
                limit = cp.get(sec, "limit", fallback="").strip() or None
                _vprint(f"[cloud] sezione={sec} table={table} lib={library_id} form={form} since={since} limit={limit}")
                rows = sdk.fetch_all_entries_full(library_id, form=form, since=since, limit=int(limit) if limit else None)
                n = _insert_rows(conn, table, tempo_col, id_mode, rows)
                print(f"[ok] {table} (cloud): {n}/{len(rows)} righe importate")
                total += n
            else:
                # local inline entries
                entries_blob = cp.get(sec, "entries", fallback="").strip("
")
                entries = []
                if entries_blob:
                    for rawline in entries_blob.splitlines():
                        line = rawline.strip()
                        if not line or line.startswith("#"):
                            continue
                        row = {}
                        for piece in [pp for pp in line.split(';') if pp.strip()]:
                            if "=" in piece:
                                k, v = piece.split("=", 1)
                                row[k.strip()] = v.strip()
                        if row:
                            entries.append(row)
                _vprint(f"[local] sezione={sec} table={table} entries={len(entries)}")
                n = _insert_rows(conn, table, tempo_col, id_mode, entries)
                print(f"[ok] {table} (local): {n}/{len(entries)} righe importate")
                total += n
        return total

    def _import_from_yaml(conn: sqlite3.Connection, data) -> int:
        # Accept {'batches':[...]} or list or dict mapping
        if isinstance(data, dict) and "batches" in data:
            items = data["batches"] or []
        elif isinstance(data, list):
            items = data
        elif isinstance(data, dict):
            # table->obj
            items = [{"table": k, **v} for k, v in data.items() if isinstance(v, dict)]
        else:
            items = []

        total = 0
        for it in items:
            table = it.get("table") or it.get("name")
            if not table:
                continue
            id_mode = (it.get("id_mode") or "id").lower()
            tempo_col = it.get("tempo_col") or it.get("tempo") or "tempo"
            entries = it.get("entries") or []
            n = _insert_rows(conn, table, tempo_col, id_mode, entries)
            print(f"[ok] {table} (yaml): {n}/{len(entries)} righe importate")
            total += n
        return total

    def memento_import_batch(db_path: str, batch_path: str) -> int:
        db = resolve_here(db_path)
        batch = resolve_here(batch_path)
        conn = sqlite3.connect(str(db))
        try:
            obj = _load_batch_file(str(batch))
            if obj["kind"] == "ini":
                return _import_from_ini(conn, obj["cp"])
            elif obj["kind"] == "yaml":
                return _import_from_yaml(conn, obj["data"])
            else:
                raise RuntimeError("Formato batch non riconosciuto")
        finally:
            conn.close()
