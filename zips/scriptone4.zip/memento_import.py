# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sqlite3, json, datetime as dt
import yaml

from db_utils import quote_ident, table_columns, ensure_ext_col_migrated

ACCEPT_KEYS = ("imports", "tabelle", "tables", "batch")

def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def _pick_tasks(cfg: dict, yml_path: str) -> list[dict]:
    for k in ACCEPT_KEYS:
        if k in cfg and isinstance(cfg[k], list):
            return cfg[k]
    if all(key in cfg for key in ("table", "entries")):
        return [cfg]
    keys = ", ".join(ACCEPT_KEYS)
    raise RuntimeError(
        f"YAML senza sezione {keys}. File: {yml_path}\n"
        f"Chiavi viste: {list(cfg.keys())}"
    )

def memento_import_batch(db_path: str, yaml_path: str):
    cfg = load_yaml(yaml_path)
    tasks = _pick_tasks(cfg, yaml_path)
    conn = sqlite3.connect(db_path)
    try:
        for t in tasks:
            table = t["table"]
            # time_column può essere:
            #  - stringa (es. "tempo"): usa/crea quella colonna
            #  - False / None: NON usare/creare alcuna colonna tempo
            tc = t.get("time_column", "tempo")
            if tc is False or tc is None:
                tempo_col = None
            else:
                tempo_col = str(tc)
            entries = t.get("entries", [])
            id_mode = t.get("id_mode", "surrogate")
            _import_entries(conn, table, entries, id_mode, tempo_col)
        conn.commit()
    finally:
        conn.close()

def _import_entries(conn: sqlite3.Connection, table: str, entries: list[dict], id_mode: str, tempo_col: str|None):
    ext_col = ensure_ext_col_migrated(conn, table)

    def _normalize_time(val):
        if val is None:
            return None
        if isinstance(val, (int, float)):
            return dt.datetime.utcfromtimestamp(val).isoformat(timespec="seconds")
        if isinstance(val, dt.datetime):
            return val.isoformat(timespec="seconds")
        return str(val)

    # Assicura le colonne base (tranne tempo_col se None)
    _ensure_base_columns(conn, table, tempo_col)

    for e in entries:
        ext_id = e.get("ext_id") or e.get("memento_id") or e.get("id") or e.get("key")
        if not ext_id:
            if id_mode == "surrogate":
                ext_id = f"auto:{hash(json.dumps(e, sort_keys=True))}"
            else:
                continue

        # Costruisci SET/INSERT dinamici
        cols = []
        vals = []

        if tempo_col:
            tempo_val = _normalize_time(e.get(tempo_col) or e.get("tempo") or e.get("time"))
            cols.append(tempo_col); vals.append(tempo_val)

        # colonne opzionali comuni
        for k in ("second_time", "umore", "note", "createdTime", "modifiedTime"):
            cols.append(k); vals.append(e.get(k))

        raw_json = json.dumps(e, ensure_ascii=False)
        cols.append("raw"); vals.append(raw_json)

        # Esiste già?
        row = conn.execute(
            f"SELECT {quote_ident(ext_col)} FROM {quote_ident(table)} WHERE {quote_ident(ext_col)}=?",
            (ext_id,)
        ).fetchone()

        if row:
            set_clause = ", ".join(f"{quote_ident(c)}=?" for c in cols)
            conn.execute(
                f"UPDATE {quote_ident(table)} SET {set_clause} WHERE {quote_ident(ext_col)}=?",
                (*vals, ext_id)
            )
        else:
            ins_cols = ", ".join(quote_ident(c) for c in ([ext_col] + cols))
            qmarks = ", ".join(["?"] * (1 + len(vals)))
            conn.execute(
                f"INSERT INTO {quote_ident(table)} ({ins_cols}) VALUES ({qmarks})",
                (ext_id, *vals)
            )

def _ensure_base_columns(conn: sqlite3.Connection, table: str, tempo_col: str|None):
    cols = set(table_columns(conn, table))
    # Se non esiste ancora la tabella, creala minima
    conn.execute(f"CREATE TABLE IF NOT EXISTS {quote_ident(table)} (id INTEGER PRIMARY KEY AUTOINCREMENT)")
    # Crea le colonne, saltando tempo_col se None
    plan = []
    if tempo_col:
        plan.append((tempo_col, "TEXT"))
    plan += [
        ("second_time", "TEXT"),
        ("umore", "INTEGER"),
        ("note", "TEXT"),
        ("createdTime", "TEXT"),
        ("modifiedTime", "TEXT"),
        ("raw", "TEXT"),
    ]
    for col, ctype in plan:
        if col not in cols:
            try:
                conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(col)} {ctype}")
            except sqlite3.OperationalError:
                # Alcune versioni SQLite su Windows possono segnalare la colonna come esistente in race; safe-ignore
                pass
    conn.commit()
