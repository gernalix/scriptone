
# -*- coding: utf-8 -*-
from __future__ import annotations
import os, time, sqlite3, json, hashlib, configparser
from typing import List, Dict, Any, Optional
try:
    import yaml  # type: ignore
except Exception:
    yaml = None

from util import resolve_here
import memento_sdk as sdk
import requests

def _vprint(*args):
    if os.environ.get("MEMENTO_VERBOSE", "0") not in ("0",""):
        print(*args)

def _cp_parser():
    return configparser.ConfigParser(
        interpolation=None,
        delimiters=('=',),
        comment_prefixes=('#',';'),
        strict=False,
    )

def _load_batch_file(path: str):
    p = resolve_here(path)
    if not p.is_file():
        raise FileNotFoundError(f"File batch non trovato: {path}")
    suf = p.suffix.lower()
    if suf in (".yml", ".yaml"):
        if yaml is None:
            raise RuntimeError("PyYAML non disponibile (installa 'pyyaml')")
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        return {"kind": "yaml", "data": data}
    if suf == ".ini":
        cp = _cp_parser()
        cp.read(p, encoding="utf-8")
        return {"kind": "ini", "cp": cp}
    raise ValueError(f"Estensione non supportata: {p.suffix}")

def _row_ext_id(row: dict, id_mode: str) -> str:
    if id_mode == "id" and row.get("id"):
        return str(row["id"])
    payload = json.dumps(row, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()

def _ensure_table(conn: sqlite3.Connection, table: str, tempo_col: str) -> None:
    cur = conn.cursor()
    cur.execute(f"CREATE TABLE IF NOT EXISTS {table} (id TEXT, ext_id TEXT UNIQUE, {tempo_col} TEXT, raw TEXT)")
    conn.commit()
    cur.close()

def _insert_rows(conn: sqlite3.Connection, table: str, tempo_col: str, id_mode: str, rows: List[Dict[str, Any]]) -> int:
    _ensure_table(conn, table, tempo_col)
    cur = conn.cursor()
    inserted = 0
    for e in rows or []:
        if not isinstance(e, dict):
            continue
        if "id" not in e:
            if "memento_id" in e: e["id"] = e["memento_id"]
            elif "ext_id" in e: e["id"] = e["ext_id"]
        ext = _row_ext_id(e, id_mode or "id")
        e["ext_id"] = ext
        if tempo_col not in e:
            e[tempo_col] = e.get("tempo") or e.get("time") or e.get("timestamp") or e.get("createdTime") or e.get("created_at")
        cur.execute(f"SELECT 1 FROM {table} WHERE ext_id=?", (ext,))
        if cur.fetchone():
            continue
        cur.execute(f"INSERT OR IGNORE INTO {table} (id, ext_id, {tempo_col}, raw) VALUES (?,?,?,?)",
                    (e.get("id"), ext, e.get(tempo_col), json.dumps(e, ensure_ascii=False)))
        if cur.rowcount:
            inserted += 1
    conn.commit()
    cur.close()
    return inserted

def _list_entry_ids_via_sdk_or_http(library_id: str) -> List[str]:
    if hasattr(sdk, "fetch_entries"):
        _vprint("[cloud] uso sdk.fetch_entries() per ottenere gli ID")
        listing = sdk.fetch_entries(library_id)
        if isinstance(listing, dict) and "results" in listing:
            listing = listing.get("results") or []
        ids = []
        for item in listing or []:
            eid = item.get("id") or item.get("_id") or item.get("entryId") or item.get("entry_id")
            if eid:
                ids.append(str(eid))
        return ids

    _vprint("[cloud] sdk.fetch_entries() non esiste: uso HTTP diretto /libraries/{id}/entries")
    base = sdk._base_url()
    params = sdk._token_params()
    url = f"{base}/libraries/{library_id}/entries"
    ids: List[str] = []
    page = 1
    while True:
        qp = dict(params)
        qp["page"] = page
        r = requests.get(url, params=qp, timeout=60)
        if r.status_code == 429:
            wait = int(r.headers.get("Retry-After", "5"))
            print(f"[warn] 429 su listing page {page}. Attendo {wait}s…")
            time.sleep(wait)
            continue
        r.raise_for_status()
        data = r.json()
        items = data.get("results") if isinstance(data, dict) else data
        items = items or []
        got = 0
        for item in items:
            eid = item.get("id") or item.get("_id") or item.get("entryId") or item.get("entry_id")
            if eid:
                ids.append(str(eid)); got += 1
        _vprint(f"[cloud] page={page} ids+={got}")
        if isinstance(data, dict) and data.get("next"):
            page += 1
            continue
        if got == 0:
            break
        page += 1
    _vprint(f"[cloud] totale id raccolti: {len(ids)}")
    return ids

def _fetch_cloud_entries_throttled(library_id: str,
                                   base_sleep: float = 0.5,
                                   max_retries: int = 5,
                                   hard_cap: Optional[int] = None) -> List[Dict[str, Any]]:
    ids = _list_entry_ids_via_sdk_or_http(library_id)
    _vprint(f"[cloud] {len(ids)} entry id(s) trovati, inizio fetch dettagliato con throttling...")
    results: List[Dict[str, Any]] = []
    for i, eid in enumerate(ids, 1):
        if hard_cap is not None and len(results) >= hard_cap:
            break
        sleep = base_sleep
        for attempt in range(max_retries + 1):
            try:
                row = sdk.get_one_raw_entry(library_id, eid)
                if isinstance(row, dict) and "entry" in row:
                    row = row["entry"] or {}
                if isinstance(row, dict):
                    row.setdefault("id", eid)
                    results.append(row)
                else:
                    results.append({"id": eid, "raw": row})
                break
            except Exception as e:
                msg = str(e)
                if "429" in msg and attempt < max_retries:
                    wait = min(60.0, sleep)
                    print(f"[warn] 429 Too Many Requests (eid={eid}). Retry in {wait:.1f}s...")
                    time.sleep(wait)
                    sleep *= 2
                    continue
                print(f"[warn] errore su eid={eid}: {e}")
                break
        time.sleep(base_sleep)
        if i % 50 == 0:
            _vprint(f"[cloud] scaricati {i}/{len(ids)} dettagli...")
    _vprint(f"[cloud] fetch dettagliato completato: {len(results)} righe." )
    return results

def _import_from_ini(conn: sqlite3.Connection, cp: configparser.ConfigParser) -> int:
    total = 0
    for sec in cp.sections():
        mode = (cp.get(sec, "mode", fallback="local") or "local").strip().lower()
        table = (cp.get(sec, "table", fallback=sec) or sec).strip()
        id_mode = (cp.get(sec, "id_mode", fallback="id") or "id").strip().lower()
        tempo_col = (cp.get(sec, "tempo_col", fallback="tempo") or "tempo").strip()

        if mode == "cloud":
            library_id = cp.get(sec, "library_id", fallback="").strip()
            cap_val = cp.get(sec, "limit", fallback="").strip()
            hard_cap = int(cap_val) if cap_val else None

            _vprint(f"[cloud] sezione={sec} table={table} lib={library_id} cap={hard_cap}")
            rows = _fetch_cloud_entries_throttled(library_id, base_sleep=0.5, max_retries=5, hard_cap=hard_cap)
            n = _insert_rows(conn, table, tempo_col, id_mode, rows)
            print(f"[ok] {table} (cloud): {n}/{len(rows)} righe importate")
            total += n
        else:
            entries_blob = cp.get(sec, "entries", fallback="").strip("\r\n")
            entries = []
            if entries_blob:
                for rawline in entries_blob.splitlines():
                    line = rawline.strip()
                    if not line or line.startswith("#") or line.startswith(";"):
                        continue
                    row = {}
                    for piece in [pp for pp in line.split(';') if pp.strip()]:
                        if "=" in piece:
                            k, v = piece.split("=", 1)
                            row[k.strip()] = v.strip()
                    if row:
                        entries.append(row)
            _vprint(f"[local] sezione={sec} table={table} entries={len(entries)}")
            n = _insert_rows(conn, table, tempo_col, id_mode, entries)
            print(f"[ok] {table} (local): {n}/{len(entries)} righe importate")
            total += n
    return total

def _import_from_yaml(conn: sqlite3.Connection, data) -> int:
    if isinstance(data, dict) and "batches" in data:
        items = data["batches"] or []
    elif isinstance(data, list):
        items = data
    elif isinstance(data, dict):
        items = [{"table": k, **v} for k, v in data.items() if isinstance(v, dict)]
    else:
        items = []

    total = 0
    for it in items:
        table = it.get("table") or it.get("name")
        if not table:
            continue
        id_mode = (it.get("id_mode") or "id").lower()
        tempo_col = it.get("tempo_col") or it.get("tempo") or "tempo"
        entries = it.get("entries") or []
        n = _insert_rows(conn, table, tempo_col, id_mode, entries)
        print(f"[ok] {table} (yaml): {n}/{len(entries)} righe importate")
        total += n
    return total

def memento_import_batch(db_path: str, batch_path: str) -> int:
    db = resolve_here(db_path)
    batch = resolve_here(batch_path)
    conn = sqlite3.connect(str(db))
    try:
        obj = _load_batch_file(str(batch))
        if obj["kind"] == "ini":
            return _import_from_ini(conn, obj["cp"])  # type: ignore[arg-type]
        elif obj["kind"] == "yaml":
            return _import_from_yaml(conn, obj["data"])  # type: ignore[arg-type]
        else:
            raise RuntimeError("Formato batch non riconosciuto")
    finally:
        conn.close()
