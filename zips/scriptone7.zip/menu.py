from __future__ import annotations
from config import get as cfg_get
from memento_sdk import (
    list_libraries,
    infer_field_mapping,
    get_one_raw_entry,
)
from memento_import import memento_import_batch

def _ask(prompt: str, default: str = "") -> str:
    x = input(f"{prompt} [{default}]: ").strip()
    return x or default

def _do_list_libs() -> None:
    print("\n============== MEMENTO – Elenco librerie ==============")
    libs = list_libraries()
    if not libs:
        print("(nessuna libreria trovata)")
        return
    for i, lib in enumerate(libs, 1):
        name = lib.get("name") or lib.get("title") or lib.get("id")
        print(f"{i:2d}. {name}  (id={lib.get('id')})")

def _do_infer_mapping() -> None:
    print("\n============== MEMENTO – Deduci mappatura campi ==============")
    lib = input("Library ID: ").strip()
    mapping = infer_field_mapping(lib)
    print(mapping)

def _do_show_one_raw() -> None:
    print("\n============== MEMENTO – Mostra 1 entry grezza ==============")
    lib = input("Library ID: ").strip()
    form = input("Form name: ").strip()
    entry = get_one_raw_entry(lib, form)
    print(entry or "(nessuna entry)")

def _menu_import_batch() -> None:
    print("\n============== MEMENTO – Import batch da YAML/INI ==============")
    db_path = _ask("Percorso DB sqlite", cfg_get("database.path"))
    batch_default = cfg_get("memento.ini_batch_path")
    yml_default = cfg_get("memento.yaml_batch_path")
    yml_or_ini = _ask("Percorso batch (.ini o .yaml)", batch_default if batch_default else yml_default)
    try:
        n = memento_import_batch(db_path, yml_or_ini)
        print("\nImport completato.")
    except Exception as e:
        print("Errore:", e)
        raise

def main_menu() -> None:
    while True:
        print("------ MEMENTO --------")
        print("1) Elenca librerie (SDK)")
        print("2) Deduci mappatura campi (SDK)")
        print("3) Mostra 1 entry grezza (SDK)")
        print("4) Importa libreria (auto)")
        print("5) Importa batch da YAML/INI")
        print("0) Indietro / Esci")
        choice = input("> ").strip()
        if choice == "1":
            _do_list_libs()
        elif choice == "2":
            _do_infer_mapping()
        elif choice == "3":
            _do_show_one_raw()
        elif choice == "4":
            print("(non implementato in questa build)")
        elif choice == "5":
            _menu_import_batch()
        elif choice == "0":
            break
        else:
            print("Scelta non valida")

if __name__ == "__main__":
    main_menu()
