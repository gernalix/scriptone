PATCH MEMENTO SDK
=================
File inclusi:
- memento_sdk.py  (drop-in replacement)

Cosa cambia
-----------
1) Lettura robusta configurazione (config.py -> CONFIG/CFG, poi settings.ini/yaml, poi env MEMENTO_*).
2) Sanificazione api_url: rimozione commenti inline (;,#), virgolette, spazi extra; forzatura "/v1".
3) Token passato in querystring (?token=...).
4) Funzioni:
   - list_libraries(): normalizza in list[dict] con id/name/title.
   - infer_field_mapping(): legge /libraries/{id} (senza /forms).
   - get_one_raw_entry(): fallback automatico a /libraries/{id}/entries se /forms/... è 404.
   - fetch_all_entries_full(): scarica tutte le entries con paginazione e dettaglio se mancano "fields".

Integrazione
------------
Sostituisci il tuo memento_sdk.py con quello incluso. Non richiede modifiche a settings.ini, ma evita
commenti sulla stessa riga dei valori (specie api_url). Esempio corretto:

[memento]
mode = cloud
api_url = https://api.mementodatabase.com/v1
token = IL_TUO_TOKEN
timeout = 20

Diagnostica rapida
------------------
# una entry (fallback auto a /entries se /forms non esiste)
python -c "from memento_sdk import get_one_raw_entry; print(get_one_raw_entry('LIB_ID','default'))"

# tutte le entries (con dettaglio se necessario)
python -c "from memento_sdk import fetch_all_entries_full; import json; print(json.dumps(fetch_all_entries_full('LIB_ID')[:2], ensure_ascii=False)[:800])"
