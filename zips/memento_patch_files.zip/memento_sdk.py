import os
import re
import json
import time
import requests

# =========================================================
# CONFIGURAZIONE ROBUSTA (autocaricamento + fallback)
# =========================================================

# 1) Prova ad importare un eventuale config.py dell'utente
CFG = {}
try:
    import config as _user_config
    CFG = getattr(_user_config, "CONFIG", getattr(_user_config, "CFG", {}))
except Exception:
    pass

def _load_local_cfg():
    """
    Carica impostazioni da settings.yaml/settings.yml o settings.ini
    cercando in: CWD, cartella di questo file, cartella padre.
    Ritorna un dict piatto tipo {"sezione.chiave": valore}.
    """
    cfg = {}
    search_dirs = [
        os.getcwd(),
        os.path.dirname(os.path.abspath(__file__)),
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ]
    ini_paths = [os.path.join(d, "settings.ini") for d in search_dirs]
    yml_paths = [os.path.join(d, "settings.yaml") for d in search_dirs] +                 [os.path.join(d, "settings.yml") for d in search_dirs]

    # YAML prima (se presente)
    for p in yml_paths:
        if os.path.exists(p):
            try:
                import yaml
                with open(p, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
                for section, kv in (data or {}).items():
                    if isinstance(kv, dict):
                        for k, v in kv.items():
                            cfg[f"{section}.{k}"] = v
                break
            except Exception:
                pass

    # poi INI
    if not cfg:
        try:
            import configparser
            cp = configparser.ConfigParser()
            for p in ini_paths:
                if os.path.exists(p):
                    cp.read(p, encoding="utf-8")
                    for section in cp.sections():
                        for k, v in cp.items(section):
                            cfg[f"{section}.{k}"] = v
                    break
        except Exception:
            pass

    return cfg

def _cfg_get(key, default=None):
    """
    Recupera una chiave dalla configurazione con priorità:
    1) oggetto CFG/CONFIG importato dal modulo utente
    2) settings.yaml/yml/ini (locali)
    3) variabili d'ambiente MEMENTO_*
    """
    val = None
    if hasattr(CFG, "get"):
        try:
            val = CFG.get(key)
        except Exception:
            val = None
    elif isinstance(CFG, dict):
        val = CFG.get(key)

    if val is None:
        local = _load_local_cfg()
        val = local.get(key)

    if val is None:
        env_map = {
            "memento.token": "MEMENTO_TOKEN",
            "memento.api_url": "MEMENTO_API_URL",
            "memento.timeout": "MEMENTO_TIMEOUT"
        }
        env_key = env_map.get(key)
        if env_key:
            val = os.environ.get(env_key, None)

    return val if val is not None else default

# =========================================================
# SUPPORTO HTTP / SANITIZZAZIONE
# =========================================================

def _sanitize_url(url: str) -> str:
    """Rimuove commenti inline (;, #), virgolette e spazi extra da una URL letta da INI/YAML."""
    if not url:
        return url
    # taglia su ; o # (commenti inline tipici nei file .ini)
    url = re.split(r"[;#]", url, maxsplit=1)[0]
    # rimuovi virgolette esterne ed eventuali spazi doppi
    url = url.strip().strip('"').strip("'")
    url = re.sub(r"\s+", " ", url).strip()
    return url

def _base_url():
    """Restituisce l'URL base corretto (aggiunge /v1 se manca)."""
    url = _cfg_get("memento.api_url", "https://api.mementodatabase.com")
    url = _sanitize_url(url or "")
    if not url.endswith("/v1") and not url.endswith("/v1/"):
        url = url.rstrip("/") + "/v1"
    return url

def _token_params():
    """Restituisce i parametri di query con il token Memento (obbligatorio)."""
    token = _cfg_get("memento.token", None)
    if not token:
        raise RuntimeError(
            "Token Memento mancante in settings.ini/settings.yaml (chiave 'memento.token') "
            "e non trovato in variabile d'ambiente MEMENTO_TOKEN."
        )
    return {"token": token}

def _timeout():
    """Timeout in secondi per le chiamate HTTP."""
    t = _cfg_get("memento.timeout", 20)
    try:
        return int(t)
    except Exception:
        return 20

def _raise_on_404(r, path):
    """Solleva errore chiaro in caso di 404 o altra risposta HTML non JSON."""
    if r.status_code == 404:
        raise RuntimeError(
            f"Memento API ha risposto 404 su {path}. "
            f"Possibili cause: token non valido, API non abilitata/endpoint errato.\n"
            f"URL chiamato: {r.request.method} {r.url}\n"
            f"Status: {r.status_code}\n"
            f"Body: {r.text}"
        )
    r.raise_for_status()

# =========================================================
# FUNZIONI PUBBLICHE USATE DAL MENU
# =========================================================

def list_libraries():
    """
    Restituisce l'elenco delle librerie come list[dict] con chiavi id/name/title normalizzate.
    Gestisce diversi formati di risposta della Cloud API.
    """
    url = f"{_base_url()}/libraries"
    r = requests.get(url, params=_token_params(), timeout=_timeout())
    _raise_on_404(r, "/libraries")

    # Prova JSON
    try:
        data = r.json()
    except Exception:
        # Se non è JSON, prova a interpretare testo come JSON, altrimenti fallback
        txt = r.text or ""
        try:
            data = json.loads(txt)
        except Exception:
            return [{"id": "raw", "name": txt.strip(), "title": txt.strip()}]

    items = None

    # 1) Se è già una lista
    if isinstance(data, list):
        items = data

    # 2) Se è un dict con chiave tipica contenente la lista
    elif isinstance(data, dict):
        for key in ("libraries", "items", "data", "results"):
            if key in data and isinstance(data[key], list):
                items = data[key]
                break

        # 3) Mappa semplice id->name
        if items is None:
            if data and all(isinstance(v, str) for v in data.values()):
                items = [{"id": k, "name": v, "title": v} for k, v in data.items()]
            else:
                # 4) Prendi eventuali valori dict come possibili librerie
                dict_values = [v for v in data.values() if isinstance(v, dict)]
                if dict_values:
                    items = dict_values

    # 5) Se è stringa o altro, crea lista di un elemento
    if items is None:
        if isinstance(data, str):
            items = [{"id": data, "name": data, "title": data}]
        else:
            items = [{"id": "raw", "name": str(data), "title": str(data)}]

    # Normalizzazione finale
    norm = []
    for it in items:
        if isinstance(it, dict):
            _id = it.get("id") or it.get("uuid") or it.get("key") or it.get("library_id")
            _name = it.get("name") or it.get("title") or it.get("label") or _id
            _title = it.get("title") or it.get("name") or _name
            norm.append({
                "id": _id or (_name or "unknown"),
                "name": _name or "",
                "title": _title or ""
            })
        else:
            s = str(it)
            norm.append({"id": s, "name": s, "title": s})

    return norm

def infer_field_mapping(library_id):
    """Restituisce i campi della libreria leggendo /libraries/{id} (niente forms)."""
    url = f"{_base_url()}/libraries/{library_id}"
    r = requests.get(url, params=_token_params(), timeout=_timeout())
    _raise_on_404(r, f"/libraries/{library_id}")
    data = r.json()
    return data.get("fields", data)

def get_one_raw_entry(library_id, form_name="default"):
    """
    Restituisce una singola entry.
    1) Prova /forms/{form}/entries
    2) Se 404, prova /entries
    3) Se /entries non include fields, prova /entries/{id}
    """
    base = _base_url()
    params = _token_params(); params["limit"] = 1

    # tentativo 1: con forms
    url1 = f"{base}/libraries/{library_id}/forms/{form_name}/entries"
    r = requests.get(url1, params=params, timeout=_timeout())
    if r.status_code == 404:
        # tentativo 2: senza forms
        url2 = f"{base}/libraries/{library_id}/entries"
        r2 = requests.get(url2, params=params, timeout=_timeout())
        _raise_on_404(r2, f"/libraries/{library_id}/entries")
        data = r2.json()
        items = data.get("entries") or data.get("items") or data
        if isinstance(items, dict):
            items = list(items.values())
        if not items:
            return items
        first = items[0]

        # se non ci sono campi, prova il dettaglio
        if not first.get("fields"):
            eid = first.get("id")
            if eid:
                url3 = f"{base}/libraries/{library_id}/entries/{eid}"
                r3 = requests.get(url3, params=_token_params(), timeout=_timeout())
                if r3.status_code == 429:
                    time.sleep(1.2)
                    r3 = requests.get(url3, params=_token_params(), timeout=_timeout())
                _raise_on_404(r3, f"/libraries/{library_id}/entries/{eid}")
                return r3.json()
        return first

    _raise_on_404(r, f"/libraries/{library_id}/forms/{form_name}/entries")
    return r.json()

# =========================================================
# UTILITÀ PER IMPORT COMPLETI
# =========================================================

def fetch_all_entries_full(library_id, limit=500):
    """Scarica tutte le entries; se la lista non contiene i campi, fa fetch dei dettagli."""
    base = _base_url()
    url = f"{base}/libraries/{library_id}/entries"
    params = _token_params(); params["limit"] = int(limit)

    all_rows = []
    while True:
        r = requests.get(url, params=params, timeout=_timeout())
        if r.status_code == 429:
            time.sleep(1.2); r = requests.get(url, params=params, timeout=_timeout())
        _raise_on_404(r, f"/libraries/{library_id}/entries")
        data = r.json()
        items = data.get("entries") or data.get("items") or data
        if isinstance(items, dict):
            items = list(items.values())
        if not items:
            break

        # se mancano i campi, prova il dettaglio (solo quando serve)
        rows = []
        for it in items:
            if it.get("fields"):
                rows.append(it)
            else:
                eid = it.get("id")
                if not eid:
                    rows.append(it); continue
                durl = f"{base}/libraries/{library_id}/entries/{eid}"
                d = requests.get(durl, params=_token_params(), timeout=_timeout())
                if d.status_code == 429:
                    time.sleep(1.2); d = requests.get(durl, params=_token_params(), timeout=_timeout())
                _raise_on_404(d, f"/libraries/{library_id}/entries/{eid}")
                rows.append(d.json())

        all_rows.extend(rows)

        # next page?
        next_url = data.get("next") or data.get("next_url")
        if next_url:
            url, params = next_url, {}  # next_url include già la query
        else:
            break

    return all_rows
