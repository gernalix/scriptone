# -*- coding: utf-8 -*-
from __future__ import annotations
from pathlib import Path
import sqlite3, json, hashlib, configparser
try:
    import yaml  # type: ignore
except Exception:
    yaml = None

from util import resolve_here

def _load_batch_file(path: str):
    p = resolve_here(path)
    if not p.is_file():
        raise FileNotFoundError(f"File batch non trovato: {path}")
    suf = p.suffix.lower()
    if suf in (".yml", ".yaml"):
        if yaml is None:
            raise RuntimeError("PyYAML non disponibile (installa 'pyyaml')")
        return yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    if suf == ".ini":
        cfg = configparser.ConfigParser()
        cfg.read(p, encoding="utf-8")
        batches = []
        for sec in cfg.sections():
            id_mode = (cfg.get(sec, "id_mode", fallback="id") or "id").lower()
            tempo_col = cfg.get(sec, "tempo_col", fallback="tempo") or "tempo"
            entries_raw = cfg.get(sec, "entries", fallback="").strip()
            entries = []
            for line in entries_raw.splitlines():
                line = line.strip()
                if not line:
                    continue
                row = {}
                for piece in [pp for pp in line.split(";") if pp.strip()]:
                    if "=" in piece:
                        k, v = piece.split("=", 1)
                        row[k.strip()] = v.strip()
                entries.append(row)
            batches.append({"table": sec, "id_mode": id_mode, "tempo_col": tempo_col, "entries": entries})
        return {"batches": batches}
    raise ValueError(f"Estensione non supportata: {p.suffix}")

def _row_ext_id(row: dict, id_mode: str) -> str:
    if id_mode == "id" and row.get("id"):
        return str(row["id"])
    payload = json.dumps(row, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()

def _import_entries(conn: sqlite3.Connection, table: str, id_mode: str, tempo_col: str, entries: list) -> int:
    cur = conn.cursor()
    cur.execute(f"CREATE TABLE IF NOT EXISTS {table} (id TEXT, ext_id TEXT UNIQUE, {tempo_col} TEXT, raw TEXT)")
    inserted = 0
    for e in entries:
        if "id" not in e:
            if "memento_id" in e:
                e["id"] = e["memento_id"]
            elif "ext_id" in e:
                e["id"] = e["ext_id"]
        ext = _row_ext_id(e, id_mode or "id")
        e["ext_id"] = ext
        e.setdefault(tempo_col, e.get("tempo"))
        cur.execute(f"SELECT 1 FROM {table} WHERE ext_id=?", (ext,))
        if cur.fetchone():
            continue
        cur.execute(f"INSERT OR IGNORE INTO {table} (id, ext_id, {tempo_col}, raw) VALUES (?,?,?,?)",
                    (e.get("id"), ext, e.get(tempo_col), json.dumps(e, ensure_ascii=False)))
        if cur.rowcount:
            inserted += 1
    conn.commit()
    cur.close()
    return inserted

def memento_import_batch(db_path: str, batch_path: str) -> int:
    db = resolve_here(db_path)
    batch = resolve_here(batch_path)
    conn = sqlite3.connect(str(db))
    try:
        doc = _load_batch_file(str(batch)) or {}
        batches = doc.get("batches") or []
        tot = 0
        for b in batches:
            table = b.get("table")
            id_mode = (b.get("id_mode") or "id").lower()
            tempo_col = b.get("tempo_col") or "tempo"
            entries = b.get("entries") or []
            tot += _import_entries(conn, table, id_mode, tempo_col, entries)
        return tot
    finally:
        conn.close()
