# -*- coding: utf-8 -*-
"""
memento_import.py — Compat wrapper exposing memento_import_batch.

This file is intentionally simple and defensive so `from memento_import import memento_import_batch`
always works when placed in the project folder.
It delegates heavy lifting to an internal implementation which is robust to nested payloads.
"""
from __future__ import annotations
import os, json, sqlite3, re
from typing import Any, Dict, List, Optional
from datetime import datetime, timezone

# Try to import the robust implementation if present (same file may already contain it).
# If not found, we provide a compact implementation here.
try:
    # If the file was already replaced with the robust implementation, import symbols directly
    from .memento_import_impl import memento_import_batch  # type: ignore
    __all__ = ["memento_import_batch"]
except Exception:
    # Fallback implementation (self-contained).
    # It expects a function `fetch_all_entries_full` in memento_sdk.py
    try:
        from memento_sdk import fetch_all_entries_full as _fetch_full
    except Exception:
        _fetch_full = None  # will raise later if used

    FLATTEN_KEYS = ("entry","fields","data","attributes","record","payload")

    def _flatten_once(e: Dict[str, Any]) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        def merge(d: Dict[str, Any]):
            for k, v in d.items():
                if isinstance(v, dict) and k in FLATTEN_KEYS:
                    merge(v)
                else:
                    out[k] = v
        if isinstance(e, dict):
            merge(e)
        return out

    FALLBACK_TIME_KEYS = [
        "tempo","time","timestamp","createdTime","created_at","modifiedTime","modified_at",
        "date","datetime","start","end","when"
    ]

    def _pick_time_field(e: Dict[str, Any], tempo_col: str) -> Optional[str]:
        if tempo_col and tempo_col in e:
            return e.get(tempo_col)
        for k in FALLBACK_TIME_KEYS:
            if k in e:
                return e.get(k)
        for k in e:
            if isinstance(k, str) and re.search(r"time|date|timestamp", k, re.I):
                return e.get(k)
        return None

    def _to_iso(value: Any) -> Optional[str]:
        if value is None:
            return None
        if isinstance(value, list) and value:
            value = value[0]
        if isinstance(value, dict):
            for k in ("iso","text","value","date","start","end"):
                if k in value and isinstance(value[k], (str,int,float)):
                    value = value[k]; break
            if isinstance(value, dict):
                return json.dumps(value, ensure_ascii=False)
        if isinstance(value, str):
            s = value.strip()
            if re.fullmatch(r"-?\d+", s):
                try:
                    n = int(s)
                    if n > 10_000_000_000:
                        dt = datetime.fromtimestamp(n/1000, tz=timezone.utc)
                    else:
                        dt = datetime.fromtimestamp(n, tz=timezone.utc)
                    return dt.isoformat()
                except Exception:
                    pass
            return s
        if isinstance(value, (int,float)):
            n = int(value)
            if n > 10_000_000_000:
                dt = datetime.fromtimestamp(n/1000, tz=timezone.utc)
            else:
                dt = datetime.fromtimestamp(n, tz=timezone.utc)
            return dt.isoformat()
        try:
            return str(value)
        except Exception:
            return None

    def _ext_id_for(e: Dict[str, Any], id_mode: str) -> str:
        if id_mode == "hash":
            import hashlib
            payload = json.dumps(e, sort_keys=True, ensure_ascii=False)
            return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]
        for k in ("id","_id","entryId","entry_id","uuid"):
            v = e.get(k)
            if v is not None and str(v).strip() != "":
                return str(v)
        import hashlib
        payload = json.dumps(e, sort_keys=True, ensure_ascii=False)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:32]

    def _insert_rows(conn: sqlite3.Connection, section_name: str, table: str, tempo_col: str, id_mode: str, rows: List[Dict[str, Any]]) -> int:
        cur = conn.cursor()
        inserted = 0
        tempo_missing = 0
        sql = f"INSERT OR REPLACE INTO {table} (ext_id, {tempo_col}, raw) VALUES (?,?,?)"
        distinct_ext = set()
        for i, raw in enumerate(rows):
            e = _flatten_once(raw) if isinstance(raw, dict) else {"raw": raw}
            ext = _ext_id_for(e, id_mode=id_mode)
            distinct_ext.add(ext)
            tval = _to_iso(_pick_time_field(e, tempo_col))
            if tval is None:
                tempo_missing += 1
                continue
            try:
                cur.execute(sql, (ext, tval, json.dumps(e, ensure_ascii=False)))
                inserted += cur.rowcount
            except Exception:
                try:
                    cur.execute(sql, (str(ext), str(tval), json.dumps(e, ensure_ascii=False)))
                    inserted += cur.rowcount
                except Exception:
                    tempo_missing += 1
        conn.commit()
        print(f"[diag] {section_name}: fetched={len(rows)} tempo_ok={len(rows)-tempo_missing} tempo_missing={tempo_missing} distinct_ext_id={len(distinct_ext)}")
        return inserted

    def _load_batch_file(batch_path: str):
        lower = (batch_path or "").lower()
        if lower.endswith(".ini"):
            import configparser
            cp = configparser.ConfigParser()
            with open(batch_path, "r", encoding="utf-8") as fh:
                cp.read_file(fh)
            return {"kind": "ini", "cp": cp}
        else:
            import yaml  # type: ignore
            with open(batch_path, "r", encoding="utf-8") as fh:
                data = yaml.safe_load(fh) or {}
            return {"kind": "yaml", "data": data}

    def _import_from_ini(conn: sqlite3.Connection, cp) -> int:
        total = 0
        for sect in cp.sections():
            mode = cp.get(sect, "mode", fallback="cloud").strip().lower()
            if mode != "cloud":
                continue
            library_id = cp.get(sect, "library_id").strip()
            table = cp.get(sect, "table").strip()
            id_mode = cp.get(sect, "id_mode", fallback="id").strip().lower()
            tempo_col = cp.get(sect, "tempo_col", fallback="tempo").strip()
            hard_cap = cp.getint(sect, "limit", fallback=None)
            if _fetch_full is None:
                raise RuntimeError("memento_sdk.fetch_all_entries_full non disponibile; controlla memento_sdk.py")
            rows = _fetch_full(library_id, limit=100)
            if hard_cap:
                rows = rows[:hard_cap]
            n = _insert_rows(conn, sect, table, tempo_col, id_mode, rows)
            print(f"[ok] {sect} (cloud): {n}/{len(rows)} righe importate")
            total += n
        return total

    def _import_from_yaml(conn: sqlite3.Connection, data):
        total = 0
        sources = data.get("sources") or data
        if isinstance(sources, dict):
            items = list(sources.values())
        else:
            items = sources
        for spec in items:
            if not isinstance(spec, dict):
                continue
            if (spec.get("mode") or "cloud").lower() != "cloud":
                continue
            library_id = str(spec["library_id"])
            table = spec["table"]
            id_mode = (spec.get("id_mode") or "id").lower()
            tempo_col = spec.get("tempo_col") or "tempo"
            hard_cap = spec.get("limit")
            if _fetch_full is None:
                raise RuntimeError("memento_sdk.fetch_all_entries_full non disponibile; controlla memento_sdk.py")
            rows = _fetch_full(library_id, limit=100)
            if hard_cap:
                rows = rows[:int(hard_cap)]
            n = _insert_rows(conn, table, table, tempo_col, id_mode, rows)
            print(f"[ok] {table} (cloud): {n}/{len(rows)} righe importate")
            total += n
        return total

    def resolve_here(p: str) -> str:
        p = (p or "").strip().strip('"').strip("'")
        if not p:
            return p
        if os.path.isabs(p):
            return p
        here = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(here, p)

    def memento_import_batch(db_path: str, batch_path: str) -> int:
        db = resolve_here(db_path)
        batch = resolve_here(batch_path)
        conn = sqlite3.connect(str(db))
        try:
            obj = _load_batch_file(str(batch))
            if obj["kind"] == "ini":
                return _import_from_ini(conn, obj["cp"])
            elif obj["kind"] == "yaml":
                return _import_from_yaml(conn, obj["data"])
            else:
                raise RuntimeError("Formato batch non riconosciuto")
        finally:
            conn.close()

    __all__ = ["memento_import_batch"]

# End of file
