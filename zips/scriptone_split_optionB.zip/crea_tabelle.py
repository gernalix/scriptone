# -*- coding: utf-8 -*-
"""
Entry point per gli strumenti 'scriptone' (split version).
- Un solo terminale.
- Compatibile con doppio clic: la finestra NON si chiude finché non premi Invio,
  a meno che tu non passi l'argomento --nopause.
"""
from __future__ import annotations
import sys, os, sqlite3, traceback

from menu import main_menu
from util import pause_if_needed, ensure_console_utf8

__VERSION__ = "v6-split"

def main() -> int:
    ensure_console_utf8()
    print("------ MEMENTO --------")
    try:
        main_menu()
        return 0
    except KeyboardInterrupt:
        print("\n[uscita] Interrotto dall'utente.")
        return 130
    except Exception as e:
        print("================================================")
        print("ERRORE NON GESTITO:\n", e)
        traceback.print_exc()
        print("================================================")
        return 1
    finally:
        pause_if_needed("--nopause" not in sys.argv)

if __name__ == "__main__":
    sys.exit(main())
