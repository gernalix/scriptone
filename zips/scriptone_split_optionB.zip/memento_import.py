# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sqlite3, json, datetime as dt

try:
    import yaml  # PyYAML
except Exception:  # pragma: no cover
    yaml = None

from db_utils import quote_ident, table_columns, pick_ext_col, ensure_ext_col_migrated

def load_yaml(path: str) -> dict:
    if yaml is None:
        raise RuntimeError("PyYAML non disponibile. Installa con: pip install pyyaml")
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def memento_import_batch(db_path: str, yaml_path: str):
    cfg = load_yaml(yaml_path)
    tasks = cfg.get("imports") or cfg.get("tabelle") or []
    if not tasks:
        raise RuntimeError("YAML senza sezione 'imports'/'tabelle'.")
    conn = sqlite3.connect(db_path)
    try:
        for t in tasks:
            table = t["table"]
            tempo_col = t.get("time_column", "tempo")
            entries = t.get("entries", [])
            id_mode = t.get("id_mode", "surrogate")
            # Opzione B: gestiamo ext_id/memento_id in modo robusto
            _import_entries(conn, table, entries, id_mode, tempo_col)
        conn.commit()
    finally:
        conn.close()

def _import_entries(conn: sqlite3.Connection, table: str, entries: list[dict], id_mode: str, tempo_col: str):
    # Garantisce che la colonna id esterno esista ed è coerente (auto-migrazione)
    ext_col = ensure_ext_col_migrated(conn, table)

    # Per semplicità, normalizziamo il tempo come ISO string (o lasciamo com'è se già stringa)
    def _normalize_time(val):
        if val is None:
            return None
        if isinstance(val, (int, float)):
            # secondi epoch
            return dt.datetime.utcfromtimestamp(val).isoformat(timespec="seconds")
        if isinstance(val, dt.datetime):
            return val.isoformat(timespec="seconds")
        return str(val)

    for e in entries:
        ext_id = e.get("ext_id") or e.get("memento_id") or e.get("id") or e.get("key")
        if not ext_id:
            # genera una surrogate se richiesto; altrimenti salta
            if id_mode == "surrogate":
                ext_id = f"auto:{hash(json.dumps(e, sort_keys=True))}"
            else:
                continue
        tempo_val = _normalize_time(e.get(tempo_col) or e.get("tempo") or e.get("time"))

        # Esiste già?
        row = conn.execute(
            f"SELECT {quote_ident(ext_col)} FROM {quote_ident(table)} WHERE {quote_ident(ext_col)}=?",
            (ext_id,)
        ).fetchone()

        # Prepara colonne opzionali comuni
        second_time = e.get("second_time")
        umore = e.get("umore")
        note = e.get("note")
        created = e.get("createdTime") or e.get("created")
        modified = e.get("modifiedTime") or e.get("modified")
        raw_json = json.dumps(e, ensure_ascii=False)

        if row:
            conn.execute(
                f"UPDATE {quote_ident(table)} "
                f"SET {quote_ident(tempo_col)}=?, second_time=?, umore=?, note=?, createdTime=?, modifiedTime=?, raw=? "
                f"WHERE {quote_ident(ext_col)}=?",
                (tempo_val, second_time, umore, note, created, modified, raw_json, ext_id)
            )
        else:
            # Assicura che le colonne base esistano
            _ensure_base_columns(conn, table, tempo_col)
            conn.execute(
                f"INSERT INTO {quote_ident(table)} "
                f"({quote_ident(ext_col)}, {quote_ident(tempo_col)}, second_time, umore, note, createdTime, modifiedTime, raw) "
                f"VALUES (?,?,?,?,?,?,?,?)",
                (ext_id, tempo_val, second_time, umore, note, created, modified, raw_json)
            )

def _ensure_base_columns(conn: sqlite3.Connection, table: str, tempo_col: str):
    cols = set(table_columns(conn, table))
    # crea colonne se mancanti (id INTEGER PK è dato per scontato già esistente)
    for col, ctype in [
        (tempo_col, "TEXT"),
        ("second_time", "TEXT"),
        ("umore", "INTEGER"),
        ("note", "TEXT"),
        ("createdTime", "TEXT"),
        ("modifiedTime", "TEXT"),
        ("raw", "TEXT"),
    ]:
        if col not in cols:
            conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(col)} {ctype}")
    conn.commit()
