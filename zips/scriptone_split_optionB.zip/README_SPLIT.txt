Scriptone (split minimal) — Opzione B
====================================
Contenuto
- crea_tabelle.py        → entry point avviabile con doppio clic (pausa automatica)
- menu.py                → menu testuale (una sola finestra/terminale)
- util.py                → utilità (pausa, colori, input)
- db_utils.py            → helper per SQLite, migrazione ext_id
- memento_import.py      → "Import batch da YAML" con fallback ext_id/memento_id

Novità chiave
- Opzione B implementata: se la tabella ha `memento_id` ma non `ext_id`, lo script crea `ext_id`,
  copia i valori esistenti e crea un indice unico; se mancano entrambe, crea `ext_id`.
- Il menu mantiene le voci storiche; le voci 1..4 al momento stampano un placeholder.
- Nessuna apertura di più terminali: tutto avviene nello stesso processo.

Uso rapido
1) Metti questi file nella cartella del progetto.
2) Fai doppio clic su "crea_tabelle.py" (oppure da console: `python crea_tabelle.py --nopause`).
3) Scegli l'opzione 5 e indica:
   - Percorso DB (default: output.db)
   - Percorso YAML (default: memento_import.yaml)

Requisiti
- Python 3.10+
- PyYAML (`pip install pyyaml`)

Note
- Se già possiedi tabelle con schema vecchio (solo `memento_id`) l'auto‑migrazione avviene al primo import.
- Lo script crea o allinea anche le colonne base (tempo, second_time, note, ecc.) se mancano.
