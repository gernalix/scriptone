# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, os, re

def pause_if_needed(should_pause: bool):
    # Pausa utile per avvio con doppio clic; passare --nopause per evitare la pausa
    try:
        if should_pause:
            input("\nPremi Invio per uscire...")
    except EOFError:
        pass

def ensure_console_utf8():
    try:
        import codecs
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

def input_int(prompt: str) -> int:
    try:
        return int(input(prompt).strip())
    except Exception:
        return -1

def ensure_path(path: str, should_exist: bool, kind: str):
    if should_exist and not os.path.exists(path):
        raise FileNotFoundError(f"{kind} non trovato: {path}")

def color(name: str, text: str) -> str:
    # Solo accenno per leggibilità in console, disattivabile in futuro
    colors = {
        "giallo": "\033[33m",
        "verde": "\033[32m",
        "rosso": "\033[31m",
        "reset": "\033[0m",
    }
    return f"{colors.get(name,'')}{text}{colors['reset']}"
