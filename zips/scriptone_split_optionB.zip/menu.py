# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sys, sqlite3, traceback

from memento_import import memento_import_batch
from util import input_int, ensure_path, color

DEFAULT_DB = os.environ.get("SCRIPTONE_DB", "output.db")
DEFAULT_YAML = os.environ.get("SCRIPTONE_MEMENTO_YAML", "memento_import.yaml")

def main_menu():
    while True:
        print("------ MEMENTO --------")
        print("1) Elenca librerie (SDK)")
        print("2) Deduci mappatura campi (SDK)")
        print("3) Mostra 1 entry grezza (SDK)")
        print("4) Importa libreria (auto)")
        print("5) Importa batch da YAML")
        print("0) Indietro / Esci")
        sel = input_int("> ")
        if sel == 0:
            return
        elif sel in (1,2,3,4):
            print(color("giallo", "Funzione non ancora implementata in questa split: %s" % sel))
        elif sel == 5:
            _menu_import_batch()
        else:
            print("Selezione non valida.")

def _menu_import_batch():
    db_path = input(f"Percorso DB sqlite [{DEFAULT_DB}]: ").strip() or DEFAULT_DB
    yml_path = input(f"Percorso YAML [{DEFAULT_YAML}]: ").strip() or DEFAULT_YAML
    ensure_path(db_path, should_exist=False, kind="file")
    ensure_path(yml_path, should_exist=True, kind="file")

    print("\n============== MEMENTO – Import batch da YAML ==============")
    try:
        memento_import_batch(db_path, yml_path)
        print("\nImport completato.")
    except Exception as e:
        print("Errore durante l'import:", e)
        traceback.print_exc()
