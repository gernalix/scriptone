# -*- coding: utf-8 -*-
from __future__ import annotations
import sqlite3, re

def quote_ident(name: str) -> str:
    # ident SQLite "safe"
    if '"' in name:
        name = name.replace('"', '""')
    return f'"{name}"'

def table_columns(conn: sqlite3.Connection, table: str) -> list[str]:
    cols = []
    cur = conn.execute(f"PRAGMA table_info({quote_ident(table)})")
    for cid, name, ctype, notnull, dflt, pk in cur.fetchall():
        cols.append(name)
    return cols

def ensure_index(conn: sqlite3.Connection, table: str, column: str, unique: bool=True):
    idx_name = f"{table}_{column}_{'uq' if unique else 'idx'}"
    try:
        conn.execute(
            f"CREATE {'UNIQUE' if unique else ''} INDEX IF NOT EXISTS {quote_ident(idx_name)} "
            f"ON {quote_ident(table)} ({quote_ident(column)})"
        )
    except sqlite3.Error:
        pass

def pick_ext_col(conn: sqlite3.Connection, table: str) -> str | None:
    cols = set(table_columns(conn, table))
    if "ext_id" in cols: return "ext_id"
    if "memento_id" in cols: return "memento_id"
    return None

def ensure_ext_col_migrated(conn: sqlite3.Connection, table: str) -> str:
    """
    Opzione B: fallback/auto-migrazione.
    - Se esiste ext_id: usa ext_id.
    - Se esiste solo memento_id: crea ext_id, copia i valori, crea indice unico.
    - Se nessuno dei due: crea ext_id.
    Ritorna il nome della colonna da usare.
    """
    cols = set(table_columns(conn, table))
    if "ext_id" in cols:
        ensure_index(conn, table, "ext_id", unique=True)
        return "ext_id"
    if "memento_id" in cols:
        conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN ext_id TEXT")
        # copia evitando di sovrascrivere eventuali valori già esistenti
        conn.execute(f"UPDATE {quote_ident(table)} SET ext_id = memento_id WHERE ext_id IS NULL")
        ensure_index(conn, table, "ext_id", unique=True)
        conn.commit()
        return "ext_id"
    # nessuna delle due -> crea ext_id
    conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN ext_id TEXT")
    ensure_index(conn, table, "ext_id", unique=True)
    conn.commit()
    return "ext_id"
