from util import resolve_here
from memento_import import memento_import_batch

def _menu_import_batch():
    db_path = input('Percorso DB sqlite [noutput.db]: ').strip() or 'noutput.db'
    batch   = input('Percorso batch (.ini o .yaml) [memento_import.ini]: ').strip() or 'memento_import.ini'

    db_path = str(resolve_here(db_path))
    batch = str(resolve_here(batch))

    n = memento_import_batch(db_path, batch)
    print(f'Import riuscito: {n} righe')
