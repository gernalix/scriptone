from pathlib import Path

def resolve_here(p: str) -> Path:
    base = Path(__file__).resolve().parent
    q = Path(p)
    return q if q.is_absolute() else (base / q)
