from pathlib import Path
import configparser, yaml
from util import resolve_here

def _load_batch_file(path: str):
    p = resolve_here(path)
    if not p.is_file():
        raise FileNotFoundError(f"File batch non trovato: {path}")
    if p.suffix.lower() in ('.yml', '.yaml'):
        return yaml.safe_load(p.read_text(encoding='utf-8'))
    elif p.suffix.lower() == '.ini':
        cfg = configparser.ConfigParser()
        cfg.read(p, encoding='utf-8')
        return cfg
    else:
        raise ValueError(f'Estensione non supportata: {p.suffix}')
