import os
import re
import json
import time
import requests
from typing import Dict, Any, List, Optional

def _get_with_backoff(url, *, params=None, timeout=None, max_tries=8, base_sleep=0.8, max_sleep=20.0):
    import random
    tries = 0
    r = None
    last_exc = None
    while tries < max_tries:
        try:
            r = requests.get(url, params=params or {}, timeout=timeout or _timeout())
            if r.status_code < 400 or r.status_code in (400,401,403,404):
                return r
            if r.status_code == 429 or 500 <= r.status_code < 600:
                retry_after = r.headers.get("Retry-After")
                if retry_after:
                    try:
                        sleep_s = float(retry_after)
                    except Exception:
                        sleep_s = None
                else:
                    sleep_s = min(max_sleep, base_sleep * (2 ** tries)) + random.uniform(0, 0.4)
                time.sleep(sleep_s or 1.0)
                tries += 1
                last_exc = None
                continue
            return r
        except requests.RequestException as ex:
            last_exc = ex
            time.sleep(min(max_sleep, base_sleep * (2 ** tries)))
            tries += 1
            continue
    if r is None and last_exc:
        raise last_exc
    return r

DEFAULT_DB_PATH = r"Z:\download\datasette5\scriptone\noutput.db"

def get_default_db_path():
    return DEFAULT_DB_PATH

CFG = {}
try:
    import config as _user_config
    CFG = getattr(_user_config, "CONFIG", getattr(_user_config, "CFG", {}))
except Exception:
    pass

def _load_local_cfg():
    cfg = {}
    search_dirs = [
        os.getcwd(),
        os.path.dirname(os.path.abspath(__file__)),
        os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    ]
    ini_paths = [os.path.join(d, "settings.ini") for d in search_dirs]
    yml_paths = [os.path.join(d, "settings.yaml") for d in search_dirs] + [os.path.join(d, "settings.yml") for d in search_dirs]

    for p in yml_paths:
        if os.path.exists(p):
            try:
                import yaml  # type: ignore
            except Exception:
                yaml = None
            if yaml:
                try:
                    with open(p, "r", encoding="utf-8") as fh:
                        y = yaml.safe_load(fh) or {}
                    if isinstance(y, dict):
                        for sect, d in y.items():
                            if isinstance(d, dict):
                                for k, v in d.items():
                                    cfg[f"{sect}.{k}"] = v
                except Exception:
                    pass

    for p in ini_paths:
        if os.path.exists(p):
            import configparser
            cp = configparser.ConfigParser()
            try:
                cp.read(p, encoding="utf-8")
                for sect in cp.sections():
                    for k, v in cp.items(sect):
                        cfg[f"{sect}.{k}"] = v
            except Exception:
                pass

    return cfg

def _cfg_get(key: str, default=None):
    val = None
    if isinstance(CFG, dict):
        val = CFG.get(key)

    if val is None:
        local = _load_local_cfg()
        val = local.get(key)

    if val is None:
        env_map = {
            "memento.token": "MEMENTO_TOKEN",
            "memento.api_url": "MEMENTO_API_URL",
            "memento.timeout": "MEMENTO_TIMEOUT"
        }
        env_key = env_map.get(key)
        if env_key:
            val = os.environ.get(env_key, None)

    return val if val is not None else default

def _sanitize_url(url: str) -> str:
    if not url:
        return url
    url = re.split(r"[;#]", str(url), maxsplit=1)[0]
    url = url.strip().strip('"').strip("'").strip()
    url = re.sub(r"\s+", "", url)
    return url

def _base_url() -> str:
    u = _cfg_get("memento.api_url", "https://api.mementodatabase.com/v1")
    return _sanitize_url(u or "" )

def _timeout() -> int:
    try:
        return int(_cfg_get("memento.timeout", 20))
    except Exception:
        return 20

def _token_params() -> Dict[str, Any]:
    token = _cfg_get("memento.token", "").strip()
    return {"token": token} if token else {}

def _raise_on_404(r: requests.Response, path: str):
    if r.status_code == 404:
        raise RuntimeError(f"Memento API ha risposto 404 su {path}. URL: {r.request.method} {r.url}\nStatus: {r.status_code}\nBody: {r.text}")
    r.raise_for_status()

def list_libraries():
    url = f"{_base_url().rstrip('/')}/libraries"
    r = _get_with_backoff(url, params=_token_params(), timeout=_timeout())
    _raise_on_404(r, "/libraries")
    try:
        data = r.json()
    except Exception:
        txt = r.text or ""
        try:
            data = json.loads(txt)
        except Exception:
            return [{"id": "raw", "name": txt.strip(), "title": txt.strip()}]

    items = None
    if isinstance(data, dict):
        items = data.get("libraries") or data.get("items") or data.get("data")
    if items is None:
        items = data
    if isinstance(items, dict):
        items = list(items.values())
    out = []
    for it in items or []:
        out.append({
            "id": it.get("id") or it.get("library_id") or it.get("uuid") or it.get("uid"),
            "name": it.get("name") or it.get("title") or it.get("label") or "",
            "title": it.get("title") or it.get("name") or ""
        })
    return out

def fetch_all_entries_full(library_id, limit=100):
    import urllib.parse as _up
    base = _base_url().rstrip("/")
    url = f"{base}/libraries/{library_id}/entries"
    params = _token_params().copy()
    params["limit"] = int(limit)

    def _listify(data):
        if isinstance(data, dict):
            items = data.get("entries") or data.get("items") or data.get("data")
        else:
            items = data
        if isinstance(items, dict):
            items = list(items.values())
        return items

    all_rows = []
    while True:
        r = _get_with_backoff(url, params=params, timeout=_timeout())
        _raise_on_404(r, f"/libraries/{library_id}/entries")
        data = r.json()
        rows = _listify(data) or []

        if rows and isinstance(rows[0], dict) and not rows[0].get("fields"):
            rows2 = []
            for e in rows:
                eid = e.get("id") or e.get("entry_id")
                if not eid:
                    rows2.append(e); continue
                durl = f"{base}/libraries/{library_id}/entries/{eid}"
                d = _get_with_backoff(durl, params=_token_params(), timeout=_timeout())
                _raise_on_404(d, f"/libraries/{library_id}/entries/{eid}")
                rows2.append(d.json())
            rows = rows2

        all_rows.extend(rows)

        next_url = None
        if isinstance(data, dict):
            next_url = data.get("next") or data.get("next_url")
            if not next_url:
                links = data.get("links") or {}
                if isinstance(links, dict):
                    next_url = links.get("next")
        if next_url:
            next_url = _up.urljoin(base + "/", next_url)
            parsed = _up.urlparse(next_url)
            q = dict(_up.parse_qsl(parsed.query))
            if "token" not in q:
                q.update(_token_params())
            url = _up.urlunparse(parsed._replace(query=_up.urlencode(q)))
            params = None
            continue

        token = None
        if isinstance(data, dict):
            token = data.get("nextPageToken") or data.get("next_page_token") or data.get("cursor") or data.get("continuation") or data.get("continuationToken")
        if token:
            url = f"{base}/libraries/{library_id}/entries"
            params = _token_params().copy()
            params["limit"] = int(limit)
            params["pageToken"] = token
            continue

        if isinstance(data, dict):
            total = data.get("total"); offset = data.get("offset")
            page = data.get("page"); pages = data.get("pages")
            if total is not None and offset is not None:
                n_off = int(offset) + int(limit)
                if n_off >= int(total): break
                url = f"{base}/libraries/{library_id}/entries"
                params = _token_params().copy(); params["limit"] = int(limit); params["offset"] = n_off
                continue
            if page is not None and pages is not None:
                p = int(page); P = int(pages)
                if p + 1 >= P: break
                url = f"{base}/libraries/{library_id}/entries"
                params = _token_params().copy(); params["limit"] = int(limit); params["page"] = p + 1
                continue

        break

    return all_rows

def probe_capabilities(library_id: str):
    base = _base_url().rstrip("/")
    url = f"{base}/libraries/{library_id}/entries"
    caps = {
        "accepts_sort": False,
        "sort_key": None,
        "accepts_updatedAfter": False,
        "accepts_createdAfter": False,
        "accepts_pageToken": False
    }

    r = _get_with_backoff(url, params={**_token_params(), "limit": 1}, timeout=_timeout())
    try:
        _ = r.json()
    except Exception:
        pass

    for key in ("modifiedTime", "updated_at", "updated", "tempo", "time"):
        rr = _get_with_backoff(url, params={**_token_params(), "limit": 1, "sort": key}, timeout=_timeout())
        if rr.status_code < 400:
            caps["accepts_sort"] = True
            caps["sort_key"] = key
            break

    for p in ("updatedAfter", "modifiedAfter"):
        rr = _get_with_backoff(url, params={**_token_params(), p: "1970-01-01T00:00:00Z", "limit": 1}, timeout=_timeout())
        if rr.status_code < 400:
            caps["accepts_updatedAfter"] = True
            break
    for p in ("createdAfter", "since"):
        rr = _get_with_backoff(url, params={**_token_params(), p: "1970-01-01T00:00:00Z", "limit": 1}, timeout=_timeout())
        if rr.status_code < 400:
            caps["accepts_createdAfter"] = True
            break

    rr = _get_with_backoff(url, params={**_token_params(), "limit": 1, "pageToken": "dummy"}, timeout=_timeout())
    if rr.status_code in (200, 400, 404):
        caps["accepts_pageToken"] = True

    return caps

def fetch_incremental(library_id: str, *, modified_after_iso: Optional[str], limit: int = 200):
    caps = probe_capabilities(library_id)
    base = _base_url().rstrip("/")
    url = f"{base}/libraries/{library_id}/entries"

    params = _token_params().copy()
    params["limit"] = int(limit)

    if modified_after_iso and caps.get("accepts_updatedAfter"):
        params["updatedAfter"] = modified_after_iso
    elif modified_after_iso and caps.get("accepts_createdAfter"):
        params["createdAfter"] = modified_after_iso

    if caps.get("accepts_sort") and caps.get("sort_key"):
        params["sort"] = caps["sort_key"]

    rows = []
    while True:
        r = _get_with_backoff(url, params=params, timeout=_timeout())
        _raise_on_404(r, f"/libraries/{library_id}/entries")
        data = r.json()
        chunk = (data.get("entries") if isinstance(data, dict) else data) or data
        if isinstance(chunk, dict):
            chunk = list(chunk.values())
        chunk = chunk or []
        rows.extend(chunk)

        token = None
        if isinstance(data, dict):
            token = data.get("nextPageToken") or data.get("next_page_token") or data.get("cursor") or data.get("continuation") or data.get("continuationToken")
        if token:
            params = _token_params().copy()
            params["limit"] = int(limit)
            if modified_after_iso:
                if caps.get("accepts_updatedAfter"):
                    params["updatedAfter"] = modified_after_iso
                elif caps.get("accepts_createdAfter"):
                    params["createdAfter"] = modified_after_iso
            if caps.get("accepts_sort") and caps.get("sort_key"):
                params["sort"] = caps["sort_key"]
            params["pageToken"] = token
            continue

        if isinstance(data, dict) and "total" in data and "offset" in data:
            total = int(data.get("total") or 0)
            offset = int(data.get("offset") or 0) + int(limit)
            if offset >= total:
                break
            params = _token_params().copy()
            params["limit"] = int(limit)
            if modified_after_iso:
                if caps.get("accepts_updatedAfter"):
                    params["updatedAfter"] = modified_after_iso
                elif caps.get("accepts_createdAfter"):
                    params["createdAfter"] = modified_after_iso
            if caps.get("accepts_sort") and caps.get("sort_key"):
                params["sort"] = caps["sort_key"]
            params["offset"] = offset
            continue

        break

    need_detail = rows and isinstance(rows[0], dict) and not rows[0].get("fields")
    if need_detail:
        out = []
        for e in rows[-500:]:
            eid = e.get("id") or e.get("entry_id")
            if not eid:
                out.append(e); continue
            durl = f"{base}/libraries/{library_id}/entries/{eid}"
            d = _get_with_backoff(durl, params=_token_params(), timeout=_timeout())
            _raise_on_404(d, f"/libraries/{library_id}/entries/{eid}")
            out.append(d.json())
        rows = out

    return rows
