import os, json, sqlite3, re
from datetime import datetime, timezone
from typing import Any, Dict, Optional, List, Tuple

from memento_sdk import fetch_all_entries_full as _fetch_full
from memento_sdk import fetch_incremental as _fetch_inc
from db_utils import ensure_ext_id, ensure_pragmas, ensure_indexes, ensure_sync_table

FALLBACK_TIME_KEYS = ["tempo", "time", "timestamp", "createdTime", "created_at", "modifiedTime", "modified_at", "date"]

def _pick_time_field(e: Dict[str, Any], tempo_col: str) -> Any:
    if tempo_col and tempo_col in e:
        return e.get(tempo_col)
    for k in FALLBACK_TIME_KEYS:
        if k in e:
            return e.get(k)
    f = e.get("fields") or {}
    if isinstance(f, dict):
        if tempo_col and tempo_col in f:
            return f.get(tempo_col)
        for k in FALLBACK_TIME_KEYS:
            if k in f:
                return f.get(k)
    return None

def _ext_id_for(e: Dict[str, Any], id_mode: str = "id") -> str:
    if id_mode == "hash":
        import hashlib, json as _json
        return hashlib.sha1(_json.dumps(e, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()
    return str(e.get("id") or e.get("_id") or e.get("entry_id") or e.get("uuid") or "")

def _to_iso(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, dict):
        for kk in ("iso", "iso8601", "rfc3339", "value"):
            if kk in value:
                value = value[kk]; break
        if isinstance(value, dict):
            return json.dumps(value, ensure_ascii=False)
    if isinstance(value, str):
        s = value.strip()
        if re.fullmatch(r"-?\d+", s):
            try:
                n = int(s)
                if n > 10_000_000_000:
                    dt = datetime.fromtimestamp(n/1000, tz=timezone.utc)
                else:
                    dt = datetime.fromtimestamp(n, tz=timezone.utc)
                return dt.isoformat()
            except Exception:
                pass
        return s
    if isinstance(value, (int, float)):
        n = int(value)
        if n > 10_000_000_000:
            dt = datetime.fromtimestamp(n/1000, tz=timezone.utc)
        else:
            dt = datetime.fromtimestamp(n, tz=timezone.utc)
        return dt.isoformat()
    return None

def _insert_rows(conn: sqlite3.Connection, table: str, tempo_col: str, id_mode: str, rows: List[Dict[str, Any]]) -> int:
    cur = conn.cursor()
    sql = f"INSERT OR IGNORE INTO {table} (ext_id, {tempo_col}, raw) VALUES (?,?,?)"
    payload = []
    for e in rows:
        ext = _ext_id_for(e, id_mode=id_mode)
        tval = _to_iso(_pick_time_field(e, tempo_col))
        if tval is None:
            continue
        payload.append((ext, tval, json.dumps(e, ensure_ascii=False)))
    if not payload:
        return 0
    cur.executemany(sql, payload)
    conn.commit()
    # sqlite3 may return -1 for executemany; fall back to len(payload)
    try:
        return cur.rowcount if cur.rowcount is not None and cur.rowcount >= 0 else len(payload)
    except Exception:
        return len(payload)

def _load_batch_file(batch_path: str) -> Dict[str, Any]:
    if batch_path.lower().endswith(".ini"):
        import configparser
        cp = configparser.ConfigParser()
        cp.read(batch_path, encoding="utf-8")
        return {"kind": "ini", "cp": cp}
    elif batch_path.lower().endswith((".yml", ".yaml")):
        try:
            import yaml  # type: ignore
        except Exception:
            raise RuntimeError("PyYAML non installato")
        with open(batch_path, "r", encoding="utf-8") as fh:
            data = yaml.safe_load(fh) or {}
        return {"kind": "yaml", "data": data}
    else:
        raise RuntimeError("Formato batch non riconosciuto (usa .ini o .yaml)")

def resolve_here(p: str) -> str:
    p = p.strip().strip('"')
    if os.path.exists(p):
        return p
    if os.path.isabs(p):
        return p
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(here, p)

def _get_sync_point(conn: sqlite3.Connection, library_id: str) -> Optional[str]:
    cur = conn.execute("SELECT last_modified_remote FROM memento_sync WHERE library_id=?", (library_id,))
    row = cur.fetchone()
    return row[0] if row else None

def _set_sync_point(conn: sqlite3.Connection, library_id: str, iso_ts: Optional[str]):
    now_iso = datetime.now(timezone.utc).isoformat()
    conn.execute(
        "INSERT INTO memento_sync(library_id,last_modified_remote,last_run_utc) VALUES(?,?,?) "
        "ON CONFLICT(library_id) DO UPDATE SET last_modified_remote=?, last_run_utc=?",
        (library_id, iso_ts, now_iso, iso_ts, now_iso)
    )
    conn.commit()

def _max_iso_from_rows(rows: List[Dict[str, Any]], tempo_col: str) -> Optional[str]:
    best = None
    for e in rows:
        v = _to_iso(_pick_time_field(e, tempo_col))
        if v is None:
            continue
        if best is None or v > best:
            best = v
    return best

def _import_section(conn: sqlite3.Connection, sect: str, cfg: Dict[str, str]) -> Tuple[str, int]:
    mode = (cfg.get("mode") or cfg.get("Mode") or "cloud").strip().lower()
    if mode != "cloud":
        raise RuntimeError("Questa build supporta solo mode=cloud")
    library_id = (cfg.get("library_id") or cfg.get("id") or "").strip()
    table = (cfg.get("table") or sect).strip()
    id_mode = (cfg.get("id_mode") or "id").strip()
    tempo_col = (cfg.get("tempo_col") or "tempo").strip()
    sync_mode = (cfg.get("sync") or "incremental").strip().lower()
    limit = int(cfg.get("limit", "300"))

    ensure_pragmas(conn)
    ensure_sync_table(conn)
    ensure_ext_id(conn, table)
    ensure_indexes(conn, table, tempo_col)

    if sync_mode == "full":
        rows = _fetch_full(library_id, limit=limit)
        inserted = _insert_rows(conn, table, tempo_col, id_mode, rows)
        last_iso = _max_iso_from_rows(rows, tempo_col)
        if last_iso:
            _set_sync_point(conn, library_id, last_iso)
        return table, inserted

    # incremental
    last_iso = _get_sync_point(conn, library_id)
    rows = _fetch_inc(library_id, modified_after_iso=last_iso, limit=limit)
    inserted = _insert_rows(conn, table, tempo_col, id_mode, rows)
    new_iso = _max_iso_from_rows(rows, tempo_col)
    if new_iso:
        _set_sync_point(conn, library_id, new_iso)
    return table, inserted

def _import_from_ini(conn: sqlite3.Connection, cp) -> int:
    total = 0
    for sect in cp.sections():
        cfg = {k: v for k, v in cp.items(sect)}
        _, n = _import_section(conn, sect, cfg)
        total += n
    return total

def _import_from_yaml(conn: sqlite3.Connection, data: Dict[str, Any]) -> int:
    total = 0
    for sect, cfg in data.items():
        if not isinstance(cfg, dict):
            continue
        _, n = _import_section(conn, sect, cfg)
        total += n
    return total

def memento_import_batch(db_path: str, batch_path: str) -> int:
    db = resolve_here(db_path)
    batch = resolve_here(batch_path)
    conn = sqlite3.connect(str(db))
    try:
        obj = _load_batch_file(str(batch))
        if obj["kind"] == "ini":
            return _import_from_ini(conn, obj["cp"])  # type: ignore[arg-type]
        elif obj["kind"] == "yaml":
            return _import_from_yaml(conn, obj["data"])  # type: ignore[arg-type]
        else:
            raise RuntimeError("Formato batch non riconosciuto")
    finally:
        conn.close()
