"""check_memento_api.py — Sonda capacità API e suggerisce la strategia di sync.
Uso:
  python check_memento_api.py memento_import.ini
  python check_memento_api.py memento_import.yaml
"""
import sys, os, json, configparser
from typing import Dict, Any
from memento_sdk import probe_capabilities

def load_sections(path: str) -> Dict[str, Dict[str, str]]:
    out: Dict[str, Dict[str, str]] = {}
    if path.lower().endswith('.ini'):
        cp = configparser.ConfigParser()
        cp.read(path, encoding='utf-8')
        for s in cp.sections():
            out[s] = {k: v for k, v in cp.items(s)}
    else:
        try:
            import yaml  # type: ignore
        except Exception:
            yaml = None
        if not yaml:
            raise SystemExit('Installa pyyaml per leggere YAML')
        with open(path, 'r', encoding='utf-8') as fh:
            y = yaml.safe_load(fh) or {}
        for s, d in (y or {}).items():
            if isinstance(d, dict):
                out[s] = {k: str(v) for k, v in d.items()}
    return out

def main():
    if len(sys.argv) < 2:
        print("Usage: python check_memento_api.py <batch.ini|.yaml>"); sys.exit(1)
    path = sys.argv[1]
    if not os.path.exists(path):
        print(f"File non trovato: {path}"); sys.exit(2)
    sections = load_sections(path)
    report = {}
    for name, cfg in sections.items():
        lib = cfg.get('library_id') or cfg.get('id') or ''
        if not lib:
            report[name] = {'error': 'library_id mancante'}
            continue
        caps = probe_capabilities(lib)
        strategy = 'updatedAfter' if caps.get('accepts_updatedAfter') else ('createdAfter' if caps.get('accepts_createdAfter') else 'paged-scan')
        report[name] = {'library_id': lib, 'caps': caps, 'suggested_strategy': strategy}
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
