from __future__ import annotations
import requests
from typing import Any, Dict, List, Optional
from urllib.parse import urljoin
from config import get as cfg_get

def _session() -> requests.Session:
    s = requests.Session()
    # Old implementations used Bearer; current Cloud API expects ?token=...
    # We keep no Authorization header to avoid confusing the gateway.
    return s

def _base_url() -> str:
    base = str(cfg_get("memento.api_url", "https://api.mementodatabase.com/v1")).rstrip("/")
    # If user configured legacy base without version, transparently add /v1
    if not base.endswith("/v1"):
        # If they already put /v2 or similar, don't touch it
        if base == "https://api.mementodatabase.com":
            base = base + "/v1"
    return base

def _token_params() -> Dict[str, str]:
    token = str(cfg_get("memento.token", "") or "").strip()
    return {"token": token} if token else {}

def _raise_on_404(resp: requests.Response, path: str) -> None:
    # Keep the nice error message the app expects
    if resp.status_code == 404:
        raise RuntimeError(
            "Memento API ha risposto 404 su {path}. Possibili cause: token non valido, API non abilitata/endpoint errato.
"
            f"URL chiamato: {resp.request.method} {resp.url}
Status: {resp.status_code}
Body: {resp.text}"
        )

def list_libraries() -> List[Dict[str, Any]]:
    s = _session()
    url = _base_url() + "/libraries"
    r = s.get(url, params=_token_params(), timeout=int(cfg_get("memento.timeout", 20)))
    if r.status_code == 404:
        _raise_on_404(r, "/libraries")
    r.raise_for_status()
    data = r.json()
    # Pipedream examples show a simple array; normalize to list
    return data if isinstance(data, list) else data.get("libraries", [])

def infer_field_mapping(library_id: str) -> Dict[str, Any]:
    s = _session()
    url = _base_url() + f"/libraries/{library_id}/fields"
    r = s.get(url, params=_token_params(), timeout=int(cfg_get("memento.timeout", 20)))
    if r.status_code == 404:
        _raise_on_404(r, f"/libraries/{library_id}/fields")
    r.raise_for_status()
    return r.json()

def get_one_raw_entry(library_id: str, form_name: str) -> Dict[str, Any]:
    s = _session()
    url = _base_url() + f"/libraries/{library_id}/forms/{form_name}/entries"
    params = {"limit": "1"}
    params.update(_token_params())
    r = s.get(url, params=params, timeout=int(cfg_get("memento.timeout", 20)))
    if r.status_code == 404:
        _raise_on_404(r, f"/libraries/{library_id}/forms/{form_name}/entries")
    r.raise_for_status()
    data = r.json()
    if isinstance(data, dict):
        # Api may return {"entries":[...]} or a plain list
        entries = data.get("entries")
        if isinstance(entries, list) and entries:
            return entries[0]
    if isinstance(data, list) and data:
        return data[0]
    return {}