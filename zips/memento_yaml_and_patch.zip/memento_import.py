# -*- coding: utf-8 -*-
from __future__ import annotations
import os, sqlite3, json, datetime as dt
import yaml

from db_utils import quote_ident, table_columns, ensure_ext_col_migrated

ACCEPT_KEYS = ("imports", "tabelle", "tables", "batch")

def load_yaml(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}

def _pick_tasks(cfg: dict, yml_path: str) -> list[dict]:
    for k in ACCEPT_KEYS:
        if k in cfg and isinstance(cfg[k], list):
            return cfg[k]
    # Fallback: se il file contiene UNA singola tabella come dict con chiavi note
    if all(key in cfg for key in ("table", "entries")):
        return [cfg]
    keys = ", ".join(ACCEPT_KEYS)
    raise RuntimeError(
        f"YAML senza sezione {keys}. File: {yml_path}\n"
        f"Chiavi viste: {list(cfg.keys())}"
    )

def memento_import_batch(db_path: str, yaml_path: str):
    cfg = load_yaml(yaml_path)
    tasks = _pick_tasks(cfg, yaml_path)
    conn = sqlite3.connect(db_path)
    try:
        for t in tasks:
            table = t["table"]
            tempo_col = t.get("time_column", "tempo")
            entries = t.get("entries", [])
            id_mode = t.get("id_mode", "surrogate")
            _import_entries(conn, table, entries, id_mode, tempo_col)
        conn.commit()
    finally:
        conn.close()

def _import_entries(conn: sqlite3.Connection, table: str, entries: list[dict], id_mode: str, tempo_col: str):
    ext_col = ensure_ext_col_migrated(conn, table)

    def _normalize_time(val):
        if val is None:
            return None
        if isinstance(val, (int, float)):
            return dt.datetime.utcfromtimestamp(val).isoformat(timespec="seconds")
        if isinstance(val, dt.datetime):
            return val.isoformat(timespec="seconds")
        return str(val)

    for e in entries:
        ext_id = e.get("ext_id") or e.get("memento_id") or e.get("id") or e.get("key")
        if not ext_id:
            if id_mode == "surrogate":
                ext_id = f"auto:{hash(json.dumps(e, sort_keys=True))}"
            else:
                continue
        tempo_val = _normalize_time(e.get(tempo_col) or e.get("tempo") or e.get("time"))

        row = conn.execute(
            f"SELECT {quote_ident(ext_col)} FROM {quote_ident(table)} WHERE {quote_ident(ext_col)}=?",
            (ext_id,)
        ).fetchone()

        second_time = e.get("second_time")
        umore = e.get("umore")
        note = e.get("note")
        created = e.get("createdTime") or e.get("created")
        modified = e.get("modifiedTime") or e.get("modified")
        raw_json = json.dumps(e, ensure_ascii=False)

        _ensure_base_columns(conn, table, tempo_col)

        if row:
            conn.execute(
                f"UPDATE {quote_ident(table)} "
                f"SET {quote_ident(tempo_col)}=?, second_time=?, umore=?, note=?, createdTime=?, modifiedTime=?, raw=? "
                f"WHERE {quote_ident(ext_col)}=?",
                (tempo_val, second_time, umore, note, created, modified, raw_json, ext_id)
            )
        else:
            conn.execute(
                f"INSERT INTO {quote_ident(table)} "
                f"({quote_ident(ext_col)}, {quote_ident(tempo_col)}, second_time, umore, note, createdTime, modifiedTime, raw) "
                f"VALUES (?,?,?,?,?,?,?,?)",
                (ext_id, tempo_val, second_time, umore, note, created, modified, raw_json)
            )

def _ensure_base_columns(conn: sqlite3.Connection, table: str, tempo_col: str):
    cols = set(table_columns(conn, table))
    for col, ctype in [
        (tempo_col, "TEXT"),
        ("second_time", "TEXT"),
        ("umore", "INTEGER"),
        ("note", "TEXT"),
        ("createdTime", "TEXT"),
        ("modifiedTime", "TEXT"),
        ("raw", "TEXT"),
    ]:
        if col not in cols:
            conn.execute(f"ALTER TABLE {quote_ident(table)} ADD COLUMN {quote_ident(col)} {ctype}")
    conn.commit()
