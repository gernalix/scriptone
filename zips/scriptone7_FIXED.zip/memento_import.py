from __future__ import annotations
import os, sqlite3, hashlib, json, configparser
from typing import Any, Dict, List
try:
    import yaml  # type: ignore
except Exception:
    yaml = None

from config import get as cfg_get

def _load_batch_file(path: str) -> Dict[str, Any]:
    if not os.path.exists(path):
        raise FileNotFoundError(f"File batch non trovato: {path}")
    lower = path.lower()
    if lower.endswith(".ini"):
        cp = configparser.ConfigParser()
        cp.read(path, encoding="utf-8")
        batches: List[Dict[str, Any]] = []
        for section in cp.sections():
            table = section
            id_mode = cp.get(section, "id_mode", fallback="id").strip().lower()
            if id_mode == "surrogate":
                id_mode = "hash"
            elif id_mode == "strict":
                id_mode = "id"
            tempo_col = cp.get(section, "tempo_col", fallback="tempo").strip() or "tempo"
            entries_blob = cp.get(section, "entries", fallback="").strip()
            entries: List[Dict[str, Any]] = []
            for line in entries_blob.strip().splitlines():
                if not line.strip():
                    continue
                row: Dict[str, Any] = {}
                for piece in [p for p in line.split(";") if p.strip()]:
                    if "=" in piece:
                        k,v = piece.split("=", 1)
                        row[k.strip()] = v.strip()
                if "id" not in row:
                    if "memento_id" in row:
                        row["id"] = row["memento_id"]
                    elif "ext_id" in row:
                        row["id"] = row["ext_id"]
                entries.append(row)
            batches.append({
                "table": table,
                "id_mode": id_mode,
                "tempo_col": tempo_col,
                "entries": entries,
            })
        return {"batches": batches}

    if yaml is None:
        raise RuntimeError("PyYAML non installato e file non è .ini")
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    if isinstance(data, dict):
        for k in ("batches","imports","tables","tabelle","batch"):
            if k in data:
                items = data[k]
                break
        else:
            items = data
    else:
        items = data

    batches: List[Dict[str, Any]] = []
    if isinstance(items, list):
        for item in items:
            if isinstance(item, dict):
                table = item.get("table") or item.get("name")
                if not table:
                    continue
                id_mode = (item.get("id_mode") or "id").lower()
                if id_mode == "surrogate":
                    id_mode = "hash"
                elif id_mode == "strict":
                    id_mode = "id"
                tempo_col = item.get("tempo_col") or item.get("time_column") or item.get("tempo") or "tempo"
                entries = item.get("entries") or []
                batches.append({"table": table, "id_mode": id_mode, "tempo_col": tempo_col, "entries": entries})
    elif isinstance(items, dict):
        for table, obj in items.items():
            if not isinstance(obj, dict):
                continue
            id_mode = (obj.get("id_mode") or "id").lower()
            if id_mode == "surrogate":
                id_mode = "hash"
            elif id_mode == "strict":
                id_mode = "id"
            tempo_col = obj.get("tempo_col") or obj.get("time_column") or obj.get("tempo") or "tempo"
            entries = obj.get("entries") or []
            batches.append({"table": table, "id_mode": id_mode, "tempo_col": tempo_col, "entries": entries})
    return {"batches": batches}

def _ensure_tables(conn: sqlite3.Connection, table: str, tempo_col: str) -> None:
    c = conn.cursor()
    c.execute(f"""
    CREATE TABLE IF NOT EXISTS {table} (
        id TEXT PRIMARY KEY,
        ext_id TEXT UNIQUE,
        {tempo_col} TEXT,
        raw TEXT
    )
    """)
    c.execute(f"CREATE INDEX IF NOT EXISTS idx_{table}_{tempo_col} ON {table}({tempo_col})")
    c.close()

def _row_ext_id(row: Dict[str, Any], id_mode: str) -> str:
    if id_mode == "id" and "id" in row and row["id"]:
        return str(row["id"])
    payload = json.dumps(row, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()

def _import_entries(conn: sqlite3.Connection, table: str, id_mode: str, tempo_col: str, entries: List[Dict[str, Any]]) -> int:
    _ensure_tables(conn, table, tempo_col)
    cur = conn.cursor()
    inserted = 0
    for e in entries:
        if "id" not in e:
            if "memento_id" in e:
                e["id"] = e["memento_id"]
            elif "ext_id" in e:
                e["id"] = e["ext_id"]
        row = dict(e)
        ext_id = _row_ext_id(row, id_mode)
        row["ext_id"] = ext_id
        row.setdefault(tempo_col, row.get("tempo"))

        cur.execute(f"SELECT 1 FROM {table} WHERE ext_id = ?", (ext_id,))
        if cur.fetchone():
            continue
        cur.execute(f"INSERT OR IGNORE INTO {table} (id, ext_id, {tempo_col}, raw) VALUES (?, ?, ?, ?)",
                    (row.get("id"), ext_id, row.get(tempo_col), json.dumps(row, ensure_ascii=False)))
        if cur.rowcount:
            inserted += 1
    conn.commit()
    cur.close()
    return inserted

def memento_import_batch(db_path: str, batch_path: str) -> int:
    if not db_path:
        db_path = cfg_get("database.path")
    if not batch_path:
        ini_path = cfg_get("memento.ini_batch_path", "memento_import.ini")
        yaml_path = cfg_get("memento.yaml_batch_path", "memento_import.yaml")
        batch_path = ini_path if os.path.exists(ini_path) else yaml_path

    doc = _load_batch_file(batch_path)
    batches = doc.get("batches") or []
    if not batches:
        print("[MEMENTO] Nessun batch trovato nello INI/YAML.")
        return 0

    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    tot = 0
    for b in batches:
        table = b["table"]
        id_mode = b.get("id_mode", "id")
        tempo_col = b.get("tempo_col", "tempo")
        entries = b.get("entries", [])
        n = _import_entries(conn, table, id_mode, tempo_col, entries)
        print(f"[ok] {table}: {n}/{len(entries)} righe importate")
        tot += n
    conn.close()
    print(f"Import completato. Inserite {tot} righe.")
    return tot
