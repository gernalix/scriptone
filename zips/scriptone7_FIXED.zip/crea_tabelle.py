import sys
import os
from pathlib import Path
os.chdir(Path(__file__).resolve().parent)
# -*- coding: utf-8 -*-
"""
Entry point per gli strumenti 'scriptone' (split v2).
- Un solo terminale.
- Doppio clic supportato: la finestra NON si chiude finché non premi Invio,
  a meno che tu non passi l'argomento --nopause.
- Tutti i default ora vivono in settings.yaml.
"""
from __future__ import annotations
import sys, traceback
from menu import main_menu
from util import pause_if_needed, ensure_console_utf8

__VERSION__ = "v7-split-settings"

def main() -> int:
    ensure_console_utf8()
    try:
        main_menu()
        return 0
    except KeyboardInterrupt:
        print("\n[uscita] Interrotto dall'utente.")
        return 130
    except Exception as e:
        print("================================================")
        print("ERRORE NON GESTITO:\n", e)
        traceback.print_exc()
        print("================================================")
        return 1
    finally:
        pause_if_needed("--nopause" not in sys.argv)

if __name__ == "__main__":
    sys.exit(main())
